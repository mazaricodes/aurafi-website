"""
Lafzi Configuration & Edition Management.
Supports two editions:
  - "base"   : Free Lafzi (2-min video cap, no denoise, no subtitle exports, no custom fonts/styles)
  - "studio" : Lafzi Studio (Unlimited video, denoise, subtitle exports, custom fonts & styles, HWID licensing)
"""
from __future__ import annotations

import os
import platform
from pathlib import Path

# Base Paths
BACKEND_DIR = Path(__file__).resolve().parent
ROOT_DIR = BACKEND_DIR.parent
DATA_DIR = ROOT_DIR / "data"
CUSTOM_FONTS_DIR = DATA_DIR / "custom_fonts"
CUSTOM_STYLES_FILE = DATA_DIR / "custom_styles.json"
INSTALL_ID_FILE = DATA_DIR / ".install_id"
LICENSE_FILE = DATA_DIR / ".license"

DATA_DIR.mkdir(parents=True, exist_ok=True)
CUSTOM_FONTS_DIR.mkdir(parents=True, exist_ok=True)

# Edition Settings
EDITION = os.getenv("LAFZI_EDITION", "base").strip().lower()
if EDITION not in ("base", "studio"):
    EDITION = "base"

APP_VERSION = "1.0.0"
APP_NAME = "Lafzi Studio" if EDITION == "studio" else "Lafzi"

# Feature Capabilities
IS_STUDIO = (EDITION == "studio")

# Free Edition Constraints
FREE_MAX_DURATION_SECONDS = 120.0  # 2 minutes max for free tier
MAX_DURATION_SECONDS: float | None = None if IS_STUDIO else FREE_MAX_DURATION_SECONDS
ALLOW_DENOISE: bool = IS_STUDIO
ALLOW_SUBTITLE_EXPORTS: bool = IS_STUDIO
ALLOW_CUSTOM_FONTS: bool = IS_STUDIO
ALLOW_CUSTOM_STYLES: bool = IS_STUDIO

# URLs (Configurable via environment or remote manifest)
UPGRADE_URL = os.getenv("LAFZI_UPGRADE_URL", "https://aurafi.studio/products/lafzi/")
LANDING_PAGE_URL = os.getenv("LAFZI_LANDING_URL", "https://aurafi.studio/products/lafzi/")
TELEMETRY_ENDPOINT = os.getenv("LAFZI_TELEMETRY_URL", "https://api.lafzi.app/telemetry")
UPDATE_CHECK_URL = os.getenv("LAFZI_UPDATE_URL", "https://aurafi.studio/products/lafzi/version.json")

def is_studio_licensed() -> bool:
    """Check if this machine has an active, cryptographically verified Studio license."""
    if not IS_STUDIO:
        return True
    try:
        from license import get_license_status
        return bool(get_license_status().get("licensed", False))
    except Exception:
        return False

def get_platform_info() -> dict:
    return {
        "system": platform.system(),
        "release": platform.release(),
        "machine": platform.machine(),
        "is_apple_silicon": platform.system() == "Darwin" and platform.machine() == "arm64",
        "is_intel_mac": platform.system() == "Darwin" and platform.machine() in ("x86_64", "i386"),
        "is_windows": platform.system() == "Windows",
    }

def get_public_config() -> dict:
    """Config dictionary exposed to the frontend UI via /api/config."""
    from license import get_license_status  # Lazy import to avoid circular dependencies

    lic = get_license_status() if IS_STUDIO else {"licensed": True, "edition": "base"}
    is_licensed = bool(lic.get("licensed", False)) if IS_STUDIO else True

    return {
        "edition": EDITION,
        "isStudio": IS_STUDIO,
        "appName": APP_NAME,
        "version": APP_VERSION,
        "isLicensed": is_licensed,
        "maxDurationSeconds": None if (IS_STUDIO and is_licensed) else FREE_MAX_DURATION_SECONDS,
        "features": {
            "cleanAudio": ALLOW_DENOISE and is_licensed,
            "subtitleExports": ALLOW_SUBTITLE_EXPORTS and is_licensed,
            "customFonts": ALLOW_CUSTOM_FONTS and is_licensed,
            "customStyles": ALLOW_CUSTOM_STYLES and is_licensed,
            "unlimitedDuration": IS_STUDIO and is_licensed,
            "canExport": is_licensed,
        },
        "license": lic,
        "urls": {
            "upgrade": UPGRADE_URL,
            "landing": LANDING_PAGE_URL,
        },
        "platform": get_platform_info(),
    }
