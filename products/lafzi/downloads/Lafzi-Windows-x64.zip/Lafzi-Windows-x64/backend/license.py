"""
Hardware-Bound Licensing System for Lafzi Studio.
Binds license keys cryptographically to the device's hardware UUID (motherboard / platform UUID)
preventing sharing or pirating across multiple computers.
"""
from __future__ import annotations

import hashlib
import hmac
import json
import os
import platform
import re
import subprocess
import ssl
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path

from config import EDITION, LICENSE_FILE

# Secret salt for cryptographic HMAC signing (production keys use this or remote activation)
MASTER_SALT = os.getenv("LAFZI_MASTER_SECRET", "LAFZI_STUDIO_SECRET_SIGN_SALT_v1_2025")

# Gumroad Product ID for Lafzi Studio (https://maxxed45.gumroad.com/l/lafzi)
GUMROAD_PRODUCT_ID = os.getenv("GUMROAD_PRODUCT_ID", "i6F1q10sSYXQrW1UU4PDHQ==")
GUMROAD_VERIFY_URL = "https://api.gumroad.com/v2/licenses/verify"


def verify_gumroad_license(license_key: str, increment_uses: bool = True) -> tuple[bool, str, dict]:
    """
    Verify license key directly with Gumroad's license verification API.
    Returns (valid: bool, message_or_error: str, purchase_data: dict).
    """
    try:
        import certifi
        ctx = ssl.create_default_context(cafile=certifi.where())
    except Exception:
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE

    payload = urllib.parse.urlencode({
        "product_id": GUMROAD_PRODUCT_ID,
        "license_key": license_key,
        "increment_uses_count": "true" if increment_uses else "false",
    }).encode("utf-8")

    req = urllib.request.Request(
        GUMROAD_VERIFY_URL,
        data=payload,
        headers={
            "User-Agent": "LafziStudio/1.0",
            "Content-Type": "application/x-www-form-urlencoded",
        },
        method="POST"
    )

    try:
        with urllib.request.urlopen(req, context=ctx, timeout=7.0) as resp:
            data = json.loads(resp.read().decode("utf-8"))
            if data.get("success"):
                purchase = data.get("purchase", {})
                if purchase.get("refunded"):
                    return False, "This Gumroad license has been refunded.", {}
                if purchase.get("chargebacked"):
                    return False, "This Gumroad license has been chargebacked.", {}
                return True, "Valid Gumroad license", purchase
            else:
                return False, data.get("message", "License does not exist for Lafzi Studio."), {}
    except urllib.error.HTTPError as e:
        try:
            err = json.loads(e.read().decode("utf-8"))
            return False, err.get("message", f"Gumroad error ({e.code})"), {}
        except Exception:
            return False, f"Gumroad server returned error ({e.code})", {}
    except urllib.error.URLError:
        return False, "network_error", {}
    except Exception as e:
        return False, str(e), {}

def _get_raw_hardware_identifier() -> str:
    """Retrieve permanent unique hardware identifier for the current machine."""
    os_name = platform.system()
    raw_id = ""

    if os_name == "Darwin":
        # macOS: IOPlatformUUID is immutable and bound to Apple Silicon / Intel logic board
        try:
            out = subprocess.check_output(
                ["ioreg", "-rd1", "-c", "IOPlatformExpertDevice"],
                stderr=subprocess.DEVNULL,
                timeout=2,
            ).decode("utf-8", errors="ignore")
            for line in out.splitlines():
                if "IOPlatformUUID" in line:
                    match = re.search(r'"IOPlatformUUID"\s*=\s*"([^"]+)"', line)
                    if match:
                        raw_id = match.group(1).strip()
                        break
        except Exception:
            pass

        if not raw_id:
            try:
                out = subprocess.check_output(["sysctl", "-n", "kern.uuid"], stderr=subprocess.DEVNULL, timeout=2)
                raw_id = out.decode("utf-8").strip()
            except Exception:
                pass

    elif os_name == "Windows":
        # Windows: MachineGuid from Registry or Win32_ComputerSystemProduct UUID
        try:
            import winreg
            with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Cryptography") as key:
                val, _ = winreg.QueryValueEx(key, "MachineGuid")
                if val:
                    raw_id = str(val).strip()
        except Exception:
            pass

        if not raw_id:
            try:
                out = subprocess.check_output(
                    ["powershell", "-NoProfile", "-Command", "(Get-CimInstance -Class Win32_ComputerSystemProduct).UUID"],
                    stderr=subprocess.DEVNULL,
                    timeout=3,
                ).decode("utf-8", errors="ignore").strip()
                if out:
                    raw_id = out
            except Exception:
                pass

    else:
        # Linux fallback: machine-id
        for p in ("/etc/machine-id", "/var/lib/dbus/machine-id"):
            path = Path(p)
            if path.exists():
                try:
                    raw_id = path.read_text(encoding="utf-8").strip()
                    if raw_id:
                        break
                except Exception:
                    pass

    if not raw_id:
        # Emergency hardware fallback using node MAC address + CPU processor ID
        import uuid
        raw_id = f"{uuid.getnode()}-{platform.node()}-{platform.processor()}"

    return raw_id

def get_machine_id() -> str:
    """
    Generate clean, user-friendly Machine Hardware ID:
    Format: LAFZI-XXXX-XXXX-XXXX
    """
    raw = _get_raw_hardware_identifier()
    digest = hashlib.sha256(f"LAFZI-HWID:{raw}".encode("utf-8")).hexdigest().upper()
    return f"LAFZI-{digest[:4]}-{digest[4:8]}-{digest[8:12]}"

def sign_activation(machine_id: str, key: str, email: str = "") -> str:
    """Create cryptographic HMAC signature tying license to this machine."""
    data = f"{machine_id}:{key.strip().upper()}:{email.strip().lower()}"
    return hmac.new(MASTER_SALT.encode("utf-8"), data.encode("utf-8"), hashlib.sha256).hexdigest()

def verify_license_data(data: dict) -> tuple[bool, str]:
    """Verify license validity and HWID match."""
    current_hwid = get_machine_id()
    saved_hwid = data.get("machine_id", "").strip().upper()
    key = data.get("key", "").strip().upper()
    email = data.get("email", "").strip().lower()
    sig = data.get("signature", "").strip()

    if not key or not saved_hwid or not sig:
        return False, "Malformed license file"

    # Strict Hardware Lock: The license machine_id must match current hardware exactly
    if saved_hwid != current_hwid:
        return False, f"License is locked to a different device ({saved_hwid}). Current device is {current_hwid}."

    expected_sig = sign_activation(saved_hwid, key, email)
    if not hmac.compare_digest(sig, expected_sig):
        # Check master test key support
        master_sig = sign_activation(saved_hwid, key, "")
        if not hmac.compare_digest(sig, master_sig):
            return False, "Invalid license signature or altered license data."

    # Check expiration if present
    expires_at = data.get("expires_at")
    if expires_at and float(expires_at) < time.time():
        return False, "License has expired."

    return True, "Valid"

def get_license_status() -> dict:
    """Check whether Lafzi Studio is active on this machine."""
    current_hwid = get_machine_id()
    if EDITION == "base":
        return {
            "licensed": True,
            "edition": "base",
            "machine_id": current_hwid,
            "message": "Free Base Edition",
        }

    if not LICENSE_FILE.exists():
        return {
            "licensed": False,
            "edition": "studio",
            "machine_id": current_hwid,
            "error": "Activation required. Please enter your Lafzi Studio license key.",
        }

    try:
        content = json.loads(LICENSE_FILE.read_text(encoding="utf-8"))
        valid, msg = verify_license_data(content)
        if valid:
            k = content.get("key", "")
            if len(k) >= 16:
                key_preview = f"{k[:8]}-••••-••••-{k[-8:]}"
            elif len(k) >= 4:
                key_preview = f"••••-••••-{k[-4:]}"
            else:
                key_preview = "Active"

            return {
                "licensed": True,
                "edition": "studio",
                "machine_id": current_hwid,
                "email": content.get("email", ""),
                "key_preview": key_preview,
                "variant": content.get("variant", ""),
                "provider": content.get("provider", "gumroad"),
                "activated_at": content.get("activated_at"),
            }
        else:
            return {
                "licensed": False,
                "edition": "studio",
                "machine_id": current_hwid,
                "error": msg,
            }
    except Exception as e:
        return {
            "licensed": False,
            "edition": "studio",
            "machine_id": current_hwid,
            "error": f"Could not read license: {e}",
        }

def activate_license(key: str, email: str = "") -> dict:
    """Activate license key on this machine."""
    key = key.strip().upper()
    email = email.strip().lower()
    current_hwid = get_machine_id()

    if not key:
        return {"ok": False, "error": "License key cannot be empty."}

    valid_key = False
    provider = "local"
    purchase_info = {}

    # Check for Gumroad license format (e.g. 91FCE45C-A50E4F74-824FF055-589A6A6C or UUID)
    is_gumroad_pattern = bool(
        re.match(r"^[A-F0-9]{8}-[A-F0-9]{8}-[A-F0-9]{8}-[A-F0-9]{8}$", key) or
        re.match(r"^[A-F0-9]{8}-[A-F0-9]{4}-[A-F0-9]{4}-[A-F0-9]{4}-[A-F0-9]{12}$", key) or
        (len(key) == 32 and re.match(r"^[A-F0-9]{32}$", key))
    )

    # 1. Attempt Gumroad online verification first
    api_ok, api_msg, purchase = verify_gumroad_license(key)
    if api_ok:
        valid_key = True
        provider = "gumroad"
        purchase_info = purchase
        if not email and purchase.get("email"):
            email = purchase["email"].strip().lower()
    elif api_msg == "network_error":
        # Offline fallback: if customer computer is offline, permit valid Gumroad format
        if is_gumroad_pattern:
            valid_key = True
            provider = "gumroad_offline"
    elif is_gumroad_pattern:
        # Gumroad was reached and rejected this key (e.g. refunded or invalid)
        return {"ok": False, "error": api_msg}

    # 2. Check internal voucher format (STU-XXXX... or LAFZI-XXXX...)
    if not valid_key and (key.startswith("STU-") or key.startswith("LAFZI-")):
        parts = key.split("-")
        if len(parts) >= 3:
            body = "-".join(parts[:-1])
            expected_chk = hashlib.sha256(f"LAFZI_KEY:{body}".encode("utf-8")).hexdigest()[:6].upper()
            if parts[-1].upper() == expected_chk:
                valid_key = True
                provider = "voucher"

    # 3. Allow master override development keys
    if not valid_key and key in ("LAFZI-STUDIO-2025", "LAFZI-STUDIO-PRO-2025", "LAFZI-DEVELOPER-LICENSE"):
        valid_key = True
        provider = "developer"

    if not valid_key:
        return {
            "ok": False,
            "error": "Invalid license key. Please check the license key from your Gumroad receipt and try again.",
        }

    sig = sign_activation(current_hwid, key, email)
    license_data = {
        "machine_id": current_hwid,
        "key": key,
        "email": email,
        "activated_at": time.time(),
        "signature": sig,
        "provider": provider,
        "variant": purchase_info.get("variants", ""),
        "order_number": purchase_info.get("order_number", ""),
    }

    try:
        LICENSE_FILE.write_text(json.dumps(license_data, indent=2), encoding="utf-8")
        return {"ok": True, "status": get_license_status()}
    except Exception as e:
        return {"ok": False, "error": f"Failed to save activation file: {e}"}

def deactivate_license() -> dict:
    """Remove active license."""
    if LICENSE_FILE.exists():
        try:
            LICENSE_FILE.unlink()
        except Exception as e:
            return {"ok": False, "error": str(e)}
    return {"ok": True}
