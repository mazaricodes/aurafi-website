"""
Multi-Language Native <-> Roman transliteration engine for Muftamar.

Supports all 18 Whisper v3 Turbo languages in Muftamar:
  Hindi (hi), English (en), Nepali (ne), Urdu (ur), Tamil (ta), Malayalam (ml),
  Gujarati (gu), Bengali (bn), Punjabi (pa), Telugu (te), Sindhi (sd), Marathi (mr),
  Kannada (kn), Pushto (ps), Malay (ms), Assamese (as), Persian (fa), Arabic (ar).

Pipeline for Romanization:
  1. Custom user dictionary (exact native or normalised key)
  2. Built-in LEXICON (Hindustani/Urdu + Punjabi + Perso-Arabic common vocabulary)
  3. Indic Brahmic offset normaliser (maps Bengali/Assamese, Gurmukhi/Punjabi,
     Gujarati, Tamil, Telugu, Kannada, Malayalam into the unified akshara engine)
  4. Akshara parser + language-aware schwa deletion (Indo-Aryan deletes schwa;
     Dravidian languages ta/ml/te/kn preserve inherent 'a')
  5. Enhanced Perso-Arabic / Urdu / Pashto / Sindhi / Persian romaniser
  6. Devanagari -> Urdu Nastaliq converter so toggling Roman <-> Native on Urdu
     projects works instantaneously without re-running Whisper.
"""
from __future__ import annotations

import re
import unicodedata

from lexicon import LEXICON

NUKTA = "\u093c"
VIRAMA = "\u094d"
ANUSVARA = "\u0902"
CHANDRABINDU = "\u0901"
VISARGA = "\u0903"

CONSONANTS = {
    "क": "k", "ख": "kh", "ग": "g", "घ": "gh", "ङ": "n",
    "च": "ch", "छ": "ch", "ज": "j", "झ": "jh", "ञ": "n",
    "ट": "t", "ठ": "th", "ड": "d", "ढ": "dh", "ण": "n",
    "त": "t", "थ": "th", "द": "d", "ध": "dh", "न": "n",
    "प": "p", "फ": "f", "ब": "b", "भ": "bh", "म": "m",
    "य": "y", "र": "r", "ल": "l", "व": "w", "ळ": "l",
    "श": "sh", "ष": "sh", "स": "s", "ह": "h",
}
NUKTA_CONSONANTS = {
    "क": "q", "ख": "kh", "ग": "gh", "ज": "z", "झ": "zh", "ड": "r", "ढ": "rh",
    "फ": "f", "य": "y", "न": "n", "र": "r", "ल": "zh",
}
PRECOMPOSED = {
    "\u0958": "क", "\u0959": "ख", "\u095a": "ग", "\u095b": "ज",
    "\u095c": "ड", "\u095d": "ढ", "\u095e": "फ", "\u095f": "य",
    "\u0929": "न", "\u0931": "र", "\u0934": "ल",
}
MATRAS = {
    "\u093e": "aa", "\u093f": "i", "\u0940": "ii", "\u0941": "u", "\u0942": "uu",
    "\u0943": "ri", "\u0947": "e", "\u0948": "ai", "\u094b": "o", "\u094c": "au",
    "\u0949": "o", "\u0945": "e", "\u0946": "e", "\u094a": "o", "\u0944": "ri",
}
INDEPENDENT = {
    "अ": "a", "आ": "aa", "इ": "i", "ई": "ii", "उ": "u", "ऊ": "uu", "ऋ": "ri",
    "ए": "e", "ऐ": "ai", "ओ": "o", "औ": "au", "ऑ": "o", "ऍ": "e", "ऎ": "e", "ऒ": "o",
}
LABIALS = {"प", "फ", "ब", "भ", "म"}
DIGITS = {chr(0x0966 + i): str(i) for i in range(10)}
PUNCT = {"।": ".", "॥": ".", "॰": ".", "ॐ": "om"}

DEVANAGARI_RE = re.compile(r"[\u0900-\u097F]")
INDIC_RE = re.compile(r"[\u0900-\u0D7F]")
ARABIC_RE = re.compile(r"[\u0600-\u06FF]")
WORD_EDGE_RE = re.compile(r"^([^\w\u0900-\u0D7F\u0600-\u06FF]*)(.*?)([^\w\u0900-\u0D7F\u0600-\u06FF]*)$", re.S)

# Dravidian scripts preserve inherent 'a' vowel in Romanization
DRAVIDIAN_LANGS = {"ta", "ml", "te", "kn"}

# Indic script blocks that share relative code-point offsets with Devanagari (0x0900)
_INDIC_BLOCKS = (
    (0x0980, 0x09FF),  # Bengali / Assamese
    (0x0A00, 0x0A7F),  # Gurmukhi (Punjabi)
    (0x0A80, 0x0AFF),  # Gujarati
    (0x0B80, 0x0BFF),  # Tamil
    (0x0C00, 0x0C7F),  # Telugu
    (0x0C80, 0x0CFF),  # Kannada
    (0x0D00, 0x0D7F),  # Malayalam
)

# Script-specific special characters before generic block offset mapping
_INDIC_SPECIAL = {
    # Gurmukhi (Punjabi)
    "\u0A70": "\u0902",        # tippi -> anusvara
    "\u0A71": "",              # addak (gemination marker)
    "\u0A5C": "ड़",            # rra -> ड़
    "\u0A72": "अ",             # iri
    "\u0A73": "उ",             # ura
    "\u0A74": "एक ओंकार",
    # Bengali / Assamese
    "\u09F0": "र",             # Assamese ra
    "\u09F1": "व",             # Assamese wa
    "\u09CE": "त्",            # khanda ta
    "\u09DC": "ड़",
    "\u09DD": "ढ़",
    "\u09DF": "य",
    # Malayalam chillu letters
    "\u0D7A": "न्",
    "\u0D7B": "न्",
    "\u0D7C": "र्",
    "\u0D7D": "ल्",
    "\u0D7E": "ळ्",
    "\u0D7F": "क्",
}

# Multi-language native vocabulary overrides (Punjabi, Gujarati, Bengali, Tamil, etc.)
MULTI_LEXICON: dict[str, str] = {
    # Punjabi (Gurmukhi)
    "ਵਿੱਚ": "vich",
    "ਵਿਚ": "vich",
    "ਭਾਸ਼ਾ": "bhasha",
    "ਪੰਜਾਬੀ": "Punjabi",
    "ਤੁਹਾਡਾ": "tuhada",
    "ਤੁਹਾਡੀ": "tuhadi",
    "ਤੁਹਾਨੂੰ": "tuhanu",
    "ਸਾਡਾ": "saada",
    "ਸਾਡੀ": "saadi",
    "ਸਾਨੂੰ": "saanu",
    "ਮੈਨੂੰ": "mainu",
    "ਤੈਨੂੰ": "tainu",
    "ਓਹਨੂੰ": "ohnu",
    "ਇਹ": "eh",
    "ਉਹ": "oh",
    "ਕੀ": "ki",
    "ਕਿਵੇਂ": "kiven",
    "ਕਿੱਥੇ": "kitthe",
    "ਕਦੋਂ": "kadon",
    "ਕਿਉਂ": "kyun",
    "ਹੈ": "hai",
    "ਹਨ": "han",
    "ਸੀ": "si",
    "ਨਾਲ": "naal",
    "ਲਈ": "layi",
    "ਵੱਲ": "vall",
    "ਗੱਲ": "gall",
    "ਗੱਲਾਂ": "gallan",
    "ਬੰਦਾ": "banda",
    "ਮੁੰਡਾ": "munda",
    "ਕੁੜੀ": "kudi",
    "ਵਧੀਆ": "vadhiya",
    "ਬਹੁਤ": "bahut",
    # Gujarati
    "ગુજરાતી": "Gujarati",
    "ભાષામાં": "bhashama",
    "તમારી": "tamari",
    "તમને": "tamne",
    "અમારી": "amari",
    "છે": "chhe",
    "નથી": "nathi",
    "શું": "shu",
    "કેમ": "kem",
    "છો": "chho",
    # Bengali / Assamese
    "বাংলা": "Bangla",
    "ভাষায়": "bhashay",
    "অসমীয়া": "Axomiya",
    "ভাঙাত": "bhashat",
    "আপনার": "apnar",
    "আমার": "amar",
    "তোমার": "tomar",
    "ভালো": "bhalo",
    "আছে": "achhe",
    "করতে": "korte",
    # Nepali / Marathi
    "नेपाली": "Nepali",
    "मराठी": "Marathi",
    "भाषामा": "bhashama",
    "भाषेत": "bhashet",
    "तपाईंको": "tapaiko",
    "हाम्रो": "hamro",
    "छ": "chha",
    "हुन्छ": "hunchha",
    "आहे": "aahe",
    "नाही": "naahi",
    "तुम्ही": "tumhi",
    # Tamil / Malayalam / Telugu / Kannada
    "தமிழ்": "Tamil",
    "மொழியில்": "mozhiyil",
    "മലയാളം": "Malayalam",
    "ഭാഷയിൽ": "bhashayil",
    "తెలుగు": "Telugu",
    "భాషలో": "bhashalo",
    "ಕನ್ನಡ": "Kannada",
    "ಭಾಷೆಯಲ್ಲಿ": "bhashayalli",
}


def _indic_to_devanagari(word: str) -> str:
    """Convert any supported Indic Brahmic script into equivalent Devanagari code-points."""
    out: list[str] = []
    for ch in word:
        if ch in _INDIC_SPECIAL:
            out.append(_INDIC_SPECIAL[ch])
            continue
        cp = ord(ch)
        mapped = ch
        for lo, hi in _INDIC_BLOCKS:
            if lo <= cp <= hi:
                dev_cp = 0x0900 + (cp - lo)
                mapped = chr(dev_cp)
                break
        out.append(mapped)
    return "".join(out)


def normalise_key(word: str) -> str:
    """Key used for dictionary lookups: NFC-ish, nukta stripped, chandrabindu->anusvara."""
    w = unicodedata.normalize("NFD", word.strip())
    for pre, base in PRECOMPOSED.items():
        w = w.replace(pre, base)
    return w.replace(NUKTA, "").replace(CHANDRABINDU, ANUSVARA).replace("\u200c", "").replace("\u200d", "")


_LEX_NORM = {normalise_key(k): v for k, v in LEXICON.items()}
_MULTI_NORM = {unicodedata.normalize("NFC", k.strip()): v for k, v in MULTI_LEXICON.items()}


# --------------------------------------------------------------------------
# Rule engine
# --------------------------------------------------------------------------
class _Unit:
    __slots__ = ("kind", "base", "nukta", "vowel", "nasal", "visarga", "deleted", "text")

    def __init__(self, kind, base="", vowel=None, text=""):
        self.kind = kind          # 'C' consonant, 'V' independent vowel, 'X' passthrough
        self.base = base
        self.nukta = False
        self.vowel = vowel        # 'a' (inherent), matra key, or None (virama)
        self.nasal = None         # None | 'anusvara' | 'chandrabindu'
        self.visarga = False
        self.deleted = False      # inherent schwa deleted
        self.text = text

    @property
    def has_vowel(self):
        if self.kind == "V":
            return True
        if self.kind == "C":
            return self.vowel is not None and not self.deleted
        return False

    def cons_roman(self):
        if self.nukta and self.base in NUKTA_CONSONANTS:
            return NUKTA_CONSONANTS[self.base]
        return CONSONANTS.get(self.base, "")


def _parse(word: str) -> list[_Unit]:
    units: list[_Unit] = []
    w = unicodedata.normalize("NFD", word)
    for ch in w:
        if ch in PRECOMPOSED:
            u = _Unit("C", PRECOMPOSED[ch], "a")
            u.nukta = True
            units.append(u)
        elif ch in CONSONANTS:
            units.append(_Unit("C", ch, "a"))
        elif ch == NUKTA:
            if units and units[-1].kind == "C":
                units[-1].nukta = True
        elif ch in MATRAS:
            if units and units[-1].kind == "C" and units[-1].vowel == "a":
                units[-1].vowel = MATRAS[ch]
            else:
                units.append(_Unit("V", vowel=MATRAS[ch]))
        elif ch == VIRAMA:
            if units and units[-1].kind == "C":
                units[-1].vowel = None
        elif ch in (ANUSVARA, CHANDRABINDU):
            if units and units[-1].kind in "CV":
                units[-1].nasal = "anusvara" if ch == ANUSVARA else "chandrabindu"
        elif ch == VISARGA:
            if units:
                units[-1].visarga = True
        elif ch in INDEPENDENT:
            units.append(_Unit("V", vowel=INDEPENDENT[ch]))
        elif ch in ("\u200c", "\u200d"):
            continue
        elif ch in DIGITS:
            units.append(_Unit("X", text=DIGITS[ch]))
        elif ch in PUNCT:
            units.append(_Unit("X", text=PUNCT[ch]))
        else:
            units.append(_Unit("X", text=ch))
    return units


def _delete_schwas(units: list[_Unit]) -> None:
    idx = [i for i, u in enumerate(units) if u.kind in "CV"]
    if len(idx) < 2:
        return
    # word-final schwa
    last = units[idx[-1]]
    if last.kind == "C" and last.vowel == "a" and not last.nasal and not last.visarga:
        last.deleted = True
    # medial: V C [a] C V   (scan right -> left)
    for k in range(len(idx) - 2, 0, -1):
        u = units[idx[k]]
        if u.kind != "C" or u.vowel != "a" or u.nasal or u.visarga:
            continue
        left, right = units[idx[k - 1]], units[idx[k + 1]]
        if not left.has_vowel:
            continue
        if right.kind != "C" or not right.has_vowel:
            continue
        # keep schwa if the left akshara is itself the end of a conjunct (C्C)
        if k >= 2 and units[idx[k - 2]].kind == "C" and units[idx[k - 2]].vowel is None:
            continue
        u.deleted = True


def _next_cv(units, i):
    for j in range(i + 1, len(units)):
        if units[j].kind in "CV":
            return units[j]
        return None
    return None


def _prev_cv(units, i):
    for j in range(i - 1, -1, -1):
        if units[j].kind in "CV":
            return units[j]
        return None
    return None


def _rule_romanise(word: str, delete_schwa: bool = True) -> str:
    units = _parse(word)
    if delete_schwa:
        _delete_schwas(units)
    out: list[str] = []
    for i, u in enumerate(units):
        if u.kind == "X":
            out.append(u.text)
            continue
        nxt = _next_cv(units, i)
        prv = _prev_cv(units, i)
        is_last = nxt is None
        closed = nxt is not None and nxt.kind == "C" and not nxt.has_vowel

        if u.kind == "C":
            r = u.cons_roman()
            # syllable-final फ is almost always "f" in Urdu (saaf, taraf, sirf)
            if u.base == "फ" and not u.nukta and not u.has_vowel:
                r = "f"
            # gemination / aspirate clusters: अच्छा -> acha, पक्का -> pakka
            if u.vowel is None and nxt is not None and nxt.kind == "C":
                r2 = nxt.cons_roman()
                if r2 == r:
                    r = r if len(r) == 1 else ""
                elif r2 == r + "h":
                    r = ""
            out.append(r)
            if u.vowel is None or u.deleted:
                if u.visarga:
                    out.append("h")
                continue
            v = u.vowel
        else:
            v = u.vowel
            # glide between vowels: गए -> gaye, लिए -> liye
            if prv is not None and prv.has_vowel:
                if v == "e":
                    out.append("ye")
                    v = None
                elif v == "ii":
                    out.append("i")
                    v = None
            elif v == "aa":
                out.append("aa")
                v = None

        if v is not None:
            if v == "a":
                # Urdu: short a before a medial, vowel-less h sounds like e (pehle, kehna)
                if delete_schwa and nxt is not None and nxt.kind == "C" and nxt.base == "ह" and not nxt.has_vowel \
                        and _next_cv(units, units.index(nxt)) is not None:
                    out.append("e")
                else:
                    out.append("a")
            elif v == "aa":
                out.append("aa" if (closed or (u.nasal and nxt is not None and nxt.kind == "C")) else "a")
            elif v == "ii":
                out.append("i" if (is_last and not u.nasal) else "ee")
            elif v == "uu":
                out.append("oo" if (not is_last or u.nasal) else "u")
            elif v == "e":
                out.append("ei" if (is_last and u.nasal) else "e")
            else:
                out.append(v)

        if u.nasal:
            if u.nasal == "anusvara" and nxt is not None and nxt.kind == "C" and nxt.base in LABIALS:
                out.append("m")
            else:
                out.append("n")
        if u.visarga:
            out.append("h")

    s = "".join(out)
    s = re.sub(r"(.)\1\1+", r"\1\1", s)  # no triple letters
    return s


# --------------------------------------------------------------------------
# Perso-Arabic / Urdu / Pashto / Sindhi / Persian / Arabic Romanizer
# --------------------------------------------------------------------------
_ARABIC_LEXICON: dict[str, str] = {
    # Common Urdu / Persian / Arabic / Pashto / Sindhi words
    "اور": "aur", "ہے": "hai", "ہیں": "hain", "تھا": "tha", "تھی": "thi", "تھے": "the",
    "میں": "mein", "ہم": "hum", "تم": "tum", "آپ": "aap", "وہ": "woh", "یہ": "yeh",
    "کیا": "kya", "کیوں": "kyun", "کیسے": "kaise", "کہاں": "kahan", "کب": "kab", "کون": "kaun",
    "نہیں": "nahi", "نا": "na", "بھی": "bhi", "تو": "toh", "ہی": "hi", "تک": "tak",
    "سے": "se", "کو": "ko", "کا": "ka", "کی": "ki", "کے": "ke", "پر": "par", "لیے": "liye",
    "ساتھ": "saath", "بعد": "baad", "پہلے": "pehle", "اب": "ab", "ابھی": "abhi", "پھر": "phir",
    "بہت": "bohat", "زیادہ": "zyada", "کم": "kam", "سب": "sab", "کچھ": "kuch", "کوئی": "koi",
    "ایک": "ek", "دو": "do", "تین": "teen", "چار": "chaar", "پانچ": "paanch",
    "اچھا": "acha", "اچھی": "achi", "اچھے": "ache", "برا": "bura", "بڑا": "bara", "چھوٹا": "chota",
    "بات": "baat", "کام": "kaam", "لوگ": "log", "لوگوں": "logon", "دن": "din", "رات": "raat",
    "وقت": "waqt", "زندگی": "zindagi", "دنیا": "dunya", "دل": "dil", "گھر": "ghar", "نام": "naam",
    "زبان": "zaban", "اردو": "Urdu", "عربي": "Arabi", "فارسی": "Farsi", "پښتو": "Pashto", "سنڌي": "Sindhi",
    "في": "fi", "من": "min", "على": "ala", "إلى": "ila", "هذا": "hadha", "هذه": "hadhihi",
    "الذي": "alladhi", "التي": "allati", "كان": "kana", "كل": "kull", "اليوم": "alyawm",
    "الله": "Allah", "انشاءالله": "Inshallah", "ماشاءالله": "Mashallah", "سبحان": "Subhan",
    "در": "dar", "با": "ba", "بر": "bar", "از": "az", "كه": "ke", "چه": "che", "را": "ra",
    "است": "ast", "بود": "bood", "شد": "shod", "می": "mi", "ایران": "Iran",
    "په": "pa", "د": "da", "او": "aw", "چې": "che", "دي": "di", "نه": "na", "ژبه": "zhaba",
    "۾": "mein", "آهي": "aahi", "۽": "ain", "جو": "jo", "جي": "ji", "جا": "ja", "ٻولي": "boli",
}

_ARABIC_CHAR_MAP = {
    "ا": "a", "أ": "a", "إ": "i", "آ": "aa", "ٱ": "a",
    "ب": "b", "پ": "p", "ت": "t", "ٹ": "t", "ث": "s",
    "ج": "j", "چ": "ch", "ح": "h", "خ": "kh",
    "د": "d", "ڈ": "d", "ذ": "z", "ر": "r", "ڑ": "r", "ز": "z", "ژ": "zh",
    "س": "s", "ش": "sh", "ص": "s", "ض": "z", "ط": "t", "ظ": "z",
    "ع": "a", "غ": "gh", "ف": "f", "ق": "q",
    "ک": "k", "ك": "k", "گ": "g", "ل": "l", "م": "m", "ن": "n", "ں": "n",
    "و": "o", "ؤ": "o", "ہ": "h", "ه": "h", "ھ": "h", "ۃ": "a", "ة": "a",
    "ء": "", "ی": "i", "ي": "i", "ے": "e", "ئ": "i", "ۓ": "e", "ى": "a",
    # Pashto additions
    "ټ": "t", "ډ": "d", "ړ": "r", "ږ": "gh", "ښ": "sh", "څ": "ts", "ځ": "dz",
    "ڼ": "n", "ۍ": "ai", "ې": "e", "ۀ": "a",
    # Sindhi additions
    "ٻ": "b", "ٺ": "th", "ٿ": "th", "ڀ": "bh", "ڃ": "j", "ڇ": "chh",
    "ڌ": "dh", "ڏ": "d", "ڍ": "dh", "ڦ": "ph", "ڪ": "k", "ڳ": "g", "ڱ": "ng", "ڻ": "n",
    "۾": "mein", "۽": "ain",
    # Diacritics & punctuation
    "۔": ".", "؟": "?", "،": ",", "؛": ";",
    "َ": "a", "ِ": "i", "ُ": "u", "ً": "an", "ٍ": "in", "ٌ": "un", "ّ": "", "ْ": "",
}


def _arabic_romanise(word: str) -> str:
    clean = word.strip()
    if clean in _ARABIC_LEXICON:
        return _ARABIC_LEXICON[clean]
    # Strip Arabic definite article 'ال' nicely if remainder is known
    if clean.startswith("ال") and len(clean) > 3:
        rest = clean[2:]
        if rest in _ARABIC_LEXICON:
            return "al-" + _ARABIC_LEXICON[rest]
    out: list[str] = []
    n = len(clean)
    for i, ch in enumerate(clean):
        if ch in ("ہ", "ه") and i == n - 1 and i > 0:
            out.append("a")
            continue
        if ch in ("ی", "ي") and i == 0:
            out.append("y")
            continue
        if ch == "و" and i == 0:
            out.append("w")
            continue
        mapped = _ARABIC_CHAR_MAP.get(ch, ch if not ARABIC_RE.match(ch) else "")
        # Insert short 'a' between consecutive consonant clusters in unvocalized Arabic/Urdu script
        if i > 0 and mapped and mapped not in ("a", "aa", "e", "i", "o", "u", "h") and out:
            prev = out[-1]
            if prev and prev[-1] not in "aeiou.":
                out.append("a")
        out.append(mapped)
    res = "".join(out)
    return re.sub(r"(.)\1\1+", r"\1\1", res)


# --------------------------------------------------------------------------
# Devanagari -> Urdu Nastaliq converter (for switching Roman <-> Native on Urdu)
# --------------------------------------------------------------------------
_DEV_TO_URDU_CONS = {
    "क": "ک", "ख": "کھ", "ग": "گ", "घ": "گھ", "ङ": "ن",
    "च": "چ", "छ": "چھ", "ज": "ج", "झ": "جھ", "ञ": "ن",
    "ट": "ٹ", "ठ": "ٹھ", "ड": "ڈ", "ढ": "ڈھ", "ण": "ن",
    "त": "ت", "थ": "تھ", "द": "د", "ध": "دھ", "न": "ن",
    "प": "پ", "फ": "پھ", "ब": "ب", "भ": "بھ", "म": "م",
    "य": "ی", "र": "ر", "ल": "ل", "व": "و", "ळ": "ل",
    "श": "ش", "ष": "ش", "स": "س", "ह": "ہ",
}
_DEV_TO_URDU_NUKTA = {
    "क": "ق", "ख": "خ", "ग": "غ", "ज": "ز", "झ": "ژ", "ड": "ڑ", "ढ": "ڑھ", "फ": "ف",
}
_DEV_TO_URDU_WORDS = {
    "है": "ہے", "हैं": "ہیں", "था": "تھا", "थी": "تھی", "थे": "تھے",
    "मैं": "میں", "में": "میں", "हम": "ہم", "तुम": "تم", "आप": "آپ",
    "यह": "یہ", "वह": "وہ", "क्या": "کیا", "क्यों": "کیوں", "कैसे": "کیسے",
    "नहीं": "نہیں", "और": "اور", "भी": "بھی", "तो": "تو", "ही": "ہی",
    "से": "سے", "को": "کو", "का": "کا", "की": "کی", "के": "کے", "पर": "پر",
    "एक": "ایک", "दो": "دو", "सब": "سب", "कुछ": "کچھ", "कोई": "کوئی",
    "बहुत": "بہत", "अच्छा": "اچھا", "बात": "بات", "काम": "کام", "लोग": "لوگ",
}


def _devanagari_to_urdu(word: str) -> str:
    m = WORD_EDGE_RE.match(word)
    pre, core, post = m.groups() if m else ("", word, "")
    if not DEVANAGARI_RE.search(core):
        return word
    if core in _DEV_TO_URDU_WORDS:
        return pre + _DEV_TO_URDU_WORDS[core] + post
    units = _parse(core)
    _delete_schwas(units)
    out: list[str] = []
    n = len(units)
    for i, u in enumerate(units):
        is_last = i == n - 1
        if u.kind == "X":
            out.append("۔" if u.text == "." else u.text)
            continue
        if u.kind == "V":
            v = u.vowel
            if v == "aa":
                out.append("آ" if i == 0 else "ا")
            elif v in ("i", "ii"):
                out.append("ای" if i == 0 else "ی")
            elif v in ("u", "uu", "o", "au"):
                out.append("او" if i == 0 else "و")
            elif v in ("e", "ai"):
                out.append("اے" if i == 0 else "ے")
            else:
                out.append("ا")
        elif u.kind == "C":
            c = _DEV_TO_URDU_NUKTA.get(u.base) if u.nukta else None
            if not c:
                c = _DEV_TO_URDU_CONS.get(u.base, "")
            out.append(c)
            if not u.deleted and u.vowel is not None:
                v = u.vowel
                if v == "aa":
                    out.append("ا")
                elif v == "i":
                    if is_last:
                        out.append("ی")
                elif v == "ii":
                    out.append("ی")
                elif v in ("u", "uu", "o", "au"):
                    out.append("و")
                elif v in ("e", "ai"):
                    out.append("ے" if is_last else "ی")
        if u.nasal:
            out.append("ں" if is_last else "ن")
    return pre + "".join(out) + post


# Common Latin / phonetic tokens Whisper occasionally mis-spells in mixed Urdu+English speech
ROMAN_FIXES: dict[str, str] = {
    "dejain": "design",
    "dijain": "design",
    "dizain": "design",
    "desain": "design",
    "dejainer": "designer",
    "dijainer": "designer",
    "binaoge": "banaoge",
    "binaogi": "banaogi",
    "binao": "banao",
    "binaya": "banaya",
    "binate": "banate",
    "binati": "banati",
    "binana": "banana",
    "binane": "banane",
    "binayenge": "banayenge",
    "binaunga": "banaunga",
    "additable": "editable",
    "aditable": "editable",
    "editeble": "editable",
    "editabel": "editable",
    "instentali": "instantly",
    "instantli": "instantly",
    "normali": "normally",
    "normalli": "normally",
    "chenj": "change",
    "chanj": "change",
    "tumare": "tumhare",
    "tumara": "tumhara",
    "tumari": "tumhari",
    "dos": "dost",
    "tonon": "dono",
    "donon": "dono",
    "wort": "watt",
    "soted": "sorted",
    "deli": "daily",
    "aprail": "April",
    "apreel": "April",
    "hamne": "humne",
    "khilaap": "khilaaf",
    "dikhaai": "dikhayi",
    "dikhai": "dikhayi",
    "berahmi": "berehmi",
    "kaarwai": "kaarvaayi",
    "choor": "chhoot",
    "phul": "full",
    "phull": "full",
    "ful": "full",
    "phulli": "fully",
    "phuli": "fully",
    "fulli": "fully",
    "haindi": "handy",
    "handi": "handy",
    "phit": "fit",
    "phast": "fast",
    "phree": "free",
    "phollow": "follow",
    "phile": "file",
    "philes": "files",
    "philm": "film",
    "phix": "fix",
    "phirst": "first",
    "phinal": "final",
    "phinally": "finally",
    "phamily": "family",
    "phamous": "famous",
    "phan": "fan",
    "phace": "face",
    "phact": "fact",
    "phail": "fail",
    "pheel": "feel",
    "phees": "fees",
    "phield": "field",
    "phight": "fight",
    "phuture": "future",
    "pholder": "folder",
    "phormat": "format",
    "phocus": "focus",
    "phrame": "frame",
    "philter": "filter",
    "pheature": "feature",
    "pheatures": "features",
    "diryak": "direct",
    "shogi": "show hogi",
    "tiye": "liye",
    "jase": "wajah se",
}

_POSTPOSITION_SUFFIXES = (
    ("न्होंने", "nhone"),
    ("वालों", " walon"),
    ("वाला", " wala"),
    ("वाली", " wali"),
    ("वाले", " wale"),
    ("ओगे", "oge"),
    ("ओगी", "ogi"),
)


# --------------------------------------------------------------------------
# Public API
# --------------------------------------------------------------------------
class Transliterator:
    def __init__(self, custom: dict[str, str] | None = None):
        self.set_custom(custom or {})

    def set_custom(self, custom: dict[str, str]):
        """custom maps either Native -> Roman, or Roman -> Roman (spelling preference)."""
        self.custom_src: dict[str, str] = {}
        self.custom_roman: dict[str, str] = {}
        for k, v in custom.items():
            k = k.strip()
            if not k:
                continue
            if INDIC_RE.search(k) or ARABIC_RE.search(k):
                self.custom_src[normalise_key(k)] = v.strip()
            else:
                self.custom_roman[k.lower()] = v.strip()

    def apply_roman_prefs(self, roman: str) -> str:
        m = WORD_EDGE_RE.match(roman)
        pre, core, post = m.groups() if m else ("", roman, "")
        low = core.lower()
        rep = self.custom_roman.get(low) or ROMAN_FIXES.get(low)
        if rep is None:
            return roman
        return pre + rep + post

    def _romanise_token(self, token: str, lang: str = "ur") -> str:
        nfc = unicodedata.normalize("NFC", token.strip())
        if nfc in _MULTI_NORM:
            return _MULTI_NORM[nfc]
        dev_token = _indic_to_devanagari(token) if not DEVANAGARI_RE.search(token) else token
        key = normalise_key(dev_token)
        hit = self.custom_src.get(key) or _LEX_NORM.get(key)
        if hit is not None:
            return hit
        delete_schwa = lang not in DRAVIDIAN_LANGS
        for dev_sfx, rom_sfx in _POSTPOSITION_SUFFIXES:
            if key.endswith(dev_sfx) and len(key) > len(dev_sfx) + 1:
                stem = key[: -len(dev_sfx)]
                stem_rom = self.custom_src.get(stem) or _LEX_NORM.get(stem) or _rule_romanise(stem, delete_schwa=delete_schwa)
                return stem_rom + rom_sfx
        return _rule_romanise(dev_token, delete_schwa=delete_schwa)

    def word(self, src: str, lang: str = "ur") -> str:
        src = src.strip()
        if not src:
            return ""
        m = WORD_EDGE_RE.match(src)
        pre, core, post = m.groups() if m else ("", src, "")
        pre = "".join(PUNCT.get(c, c) for c in pre)
        post = "".join(PUNCT.get(c, c) for c in post)
        if INDIC_RE.search(core):
            nfc = unicodedata.normalize("NFC", core)
            roman = self.custom_src.get(normalise_key(core)) or _MULTI_NORM.get(nfc)
            if roman is None and DEVANAGARI_RE.search(core):
                roman = _LEX_NORM.get(normalise_key(core))
            if roman is None:
                parts = re.split(r"([-\u2010\u2011])", core)
                roman = "".join(
                    p if p in "-\u2010\u2011" else self._romanise_token(p, lang=lang)
                    for p in parts
                )
        elif ARABIC_RE.search(core):
            roman = self.custom_src.get(normalise_key(core)) or _arabic_romanise(core)
        else:
            roman = core
        return self.apply_roman_prefs(pre + roman + post)

    def convert(self, src: str, lang: str = "ur", script: str = "roman") -> str:
        """Convert a source word into the requested script ('roman' or 'native')."""
        if script == "native":
            if lang == "ur" and DEVANAGARI_RE.search(src):
                return _devanagari_to_urdu(src)
            return src.strip()
        return self.word(src, lang=lang)

    def text(self, src: str, lang: str = "ur", script: str = "roman") -> str:
        return " ".join(self.convert(w, lang=lang, script=script) for w in src.split())
