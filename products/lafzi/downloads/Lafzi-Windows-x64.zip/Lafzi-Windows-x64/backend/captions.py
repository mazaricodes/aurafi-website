"""Caption data model helpers: word -> cue chunking, timing sanitation, SRT/VTT/ASS writers."""
from __future__ import annotations

import re
import uuid

from renderer import DEFAULT_STYLE, display_text, hex_rgb

SENTENCE_END = re.compile(r"[.?!।۔]$")


def _id() -> str:
    return uuid.uuid4().hex[:8]


def sanitize_words(words: list[dict]) -> list[dict]:
    out = []
    last_end = 0.0
    for w in words:
        text = (w.get("text") or "").strip()
        if not text:
            continue
        s = max(float(w.get("start", last_end)), 0.0)
        e = float(w.get("end", s + 0.2))
        if s < last_end - 0.35:
            s = last_end
        if e <= s:
            e = s + 0.12
        # Never let a single word stretch across a long silent pause
        e = min(e, s + 1.15)
        out.append({**w, "id": w.get("id") or _id(), "text": text, "start": round(s, 3), "end": round(e, 3)})
        last_end = e
    return out


def chunk_words(words: list[dict], max_words: int = 3, max_gap: float = 0.38, max_dur: float = 2.8,
                max_chars: int | None = None) -> list[dict]:
    words = sanitize_words(words)
    max_words = max(1, int(max_words))
    max_chars = max_chars or max(14, max_words * 9)
    cues, cur = [], []

    def flush():
        if cur:
            cues.append({"id": _id(), "start": cur[0]["start"], "end": cur[-1]["end"], "words": list(cur)})
            cur.clear()

    for w in words:
        if cur:
            gap = w["start"] - cur[-1]["end"]
            chars = sum(len(x["text"]) + 1 for x in cur) + len(w["text"])
            if (len(cur) >= max_words or gap > max_gap or SENTENCE_END.search(cur[-1]["text"])
                    or w["end"] - cur[0]["start"] > max_dur or chars > max_chars):
                flush()
        cur.append(w)
    flush()
    extend_cues(cues)
    return cues


def extend_cues(cues: list[dict], hold: float = 0.12) -> None:
    """Keep a caption on screen briefly after its last word, leaving silent gaps empty."""
    for i, c in enumerate(cues):
        last = c["words"][-1]["end"] if c["words"] else c["end"]
        nxt = cues[i + 1]["start"] if i + 1 < len(cues) else last + hold
        c["start"] = c["words"][0]["start"] if c["words"] else c["start"]
        c["end"] = round(max(last, min(last + hold, nxt - 0.04 if nxt > last else nxt)), 3)


def flatten(cues: list[dict]) -> list[dict]:
    return [w for c in cues for w in c["words"]]


# ---------------------------------------------------------------- subtitle IO
def _ts(t: float, sep: str = ",") -> str:
    t = max(0.0, t)
    h, rem = divmod(int(round(t * 1000)), 3600_000)
    m, rem = divmod(rem, 60_000)
    s, ms = divmod(rem, 1000)
    return f"{h:02d}:{m:02d}:{s:02d}{sep}{ms:03d}"


def cue_text(c: dict, style: dict | None) -> str:
    if style is None:
        return " ".join(w["text"] for w in c["words"])
    return " ".join(t for t in (display_text(w["text"], style) for w in c["words"]) if t)


def to_srt(cues: list[dict], style: dict | None = None) -> str:
    out = []
    for i, c in enumerate(cues, 1):
        out.append(f"{i}\n{_ts(c['start'])} --> {_ts(c['end'])}\n{cue_text(c, style)}\n")
    return "\n".join(out)


def to_vtt(cues: list[dict], style: dict | None = None) -> str:
    out = ["WEBVTT", ""]
    for c in cues:
        out.append(f"{_ts(c['start'], '.')} --> {_ts(c['end'], '.')}\n{cue_text(c, style)}\n")
    return "\n".join(out)


def _ass_color(hex_color: str, alpha: float = 1.0) -> str:
    r, g, b = hex_rgb(hex_color)
    a = int(round((1 - alpha) * 255))
    return f"&H{a:02X}{b:02X}{g:02X}{r:02X}"


def _ass_ts(t: float) -> str:
    cs = int(round(max(0.0, t) * 100))
    h, rem = divmod(cs, 360000)
    m, rem = divmod(rem, 6000)
    s, cc = divmod(rem, 100)
    return f"{h}:{m:02d}:{s:02d}.{cc:02d}"


def to_ass(cues: list[dict], style: dict, width: int, height: int) -> str:
    """Karaoke-timed ASS (\\k tags) - opens in Aegisub, Premiere (via plugins), DaVinci, VLC, mpv."""
    s = {**DEFAULT_STYLE, **(style or {})}
    k = min(width, height) / 1080.0
    primary = _ass_color(s["highlightColor"] if s["highlightMode"] != "none" else s["textColor"])
    secondary = _ass_color(s["textColor"])
    outline = _ass_color(s["strokeColor"])
    back = _ass_color(s["bgColor"] if s["bgBox"] else s["shadowColor"], s["bgOpacity"] if s["bgBox"] else s["shadowOpacity"])
    border_style = 3 if s["bgBox"] else 1
    cy = int(s["positionY"] / 100 * height)
    header = f"""[Script Info]
Title: Roman Urdu Captions
ScriptType: v4.00+
PlayResX: {width}
PlayResY: {height}
WrapStyle: 0
ScaledBorderAndShadow: yes

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Default,{s['fontFamily']},{int(s['fontSize'] * k)},{primary},{secondary},{outline},{back},0,0,0,0,100,100,0,0,{border_style},{max(0, s['strokeWidth'] * k):.1f},{(s['shadowOffsetY'] * k if s['shadow'] else 0):.1f},5,{int(width * (1 - s['maxWidth'] / 100) / 2)},{int(width * (1 - s['maxWidth'] / 100) / 2)},0,1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
"""
    lines = []
    for c in cues:
        parts = []
        t = c["start"]
        for w in c["words"]:
            txt = display_text(w["text"], s)
            if not txt:
                continue
            lead = max(0, int(round((w["start"] - t) * 100)))
            dur = max(1, int(round((w["end"] - w["start"]) * 100)))
            if lead:
                parts.append(f"{{\\k{lead}}}")
            parts.append(f"{{\\k{dur}}}{txt} ")
            t = w["end"]
        text = "".join(parts).rstrip()
        lines.append(f"Dialogue: 0,{_ass_ts(c['start'])},{_ass_ts(c['end'])},Default,,0,0,0,,{{\\an5\\pos({width // 2},{cy})}}{text}")
    return header + "\n".join(lines) + "\n"
