"""
Burned-in MP4 export.

Homebrew's ffmpeg ships without libass/drawtext, so instead of the `subtitles`
filter we render the caption band ourselves with Pillow (same maths as the
browser preview) and stream raw RGBA frames into ffmpeg's `overlay` filter.
Only the horizontal band that can contain captions is streamed, and frames
are reused while nothing changes, so this is quick even for long videos.
"""
from __future__ import annotations

import math
import subprocess
import threading
from pathlib import Path
from typing import Callable

from media import FFMPEG, denoise_filter
from renderer import CaptionRenderer


def _encoder_args(quality: str) -> list[str]:
    if quality == "max":
        return ["-c:v", "libx264", "-preset", "medium", "-crf", "16", "-pix_fmt", "yuv420p"]
    # Apple hardware encoder: fast and good
    return ["-c:v", "h264_videotoolbox", "-b:v", "12M" if quality == "high" else "7M", "-pix_fmt", "yuv420p"]


def export_mp4(src: Path, out: Path, cues: list[dict], style: dict, meta: dict,
               clean_audio: Path | None = None, denoise_live: bool = False,
               quality: str = "high", progress: Callable[[float], None] | None = None) -> None:
    W, H, fps, duration = meta["width"], meta["height"], meta["fps"], meta["duration"]
    rnd = CaptionRenderer(style, W, H)
    cues = sorted(cues, key=lambda c: c["start"])
    band_top, band_h = rnd.extent(cues)
    frame_bytes = W * band_h * 4
    blank = bytes(frame_bytes)
    total = max(1, int(math.ceil(duration * fps)))

    cmd = [FFMPEG, "-y", "-hide_banner", "-loglevel", "error", "-i", str(src)]
    audio_map = ["-map", "0:a?"]
    if clean_audio and clean_audio.exists():
        cmd += ["-i", str(clean_audio)]
        audio_map = ["-map", "1:a"]
        ov_idx = 2
    else:
        ov_idx = 1
    cmd += ["-f", "rawvideo", "-pix_fmt", "rgba", "-s", f"{W}x{band_h}", "-framerate", f"{fps}", "-i", "pipe:0"]
    filt = f"[0:v][{ov_idx}:v]overlay=0:{band_top}:eof_action=pass:format=auto[v]"
    cmd += ["-filter_complex", filt, "-map", "[v]"] + audio_map
    cmd += _encoder_args(quality)
    if denoise_live and not clean_audio:
        cmd += ["-af", denoise_filter()]
    cmd += ["-c:a", "aac", "-b:a", "192k", "-movflags", "+faststart", "-shortest", str(out)]

    proc = subprocess.Popen(cmd, stdin=subprocess.PIPE, stderr=subprocess.PIPE)
    err_chunks: list[bytes] = []
    t_err = threading.Thread(target=lambda: err_chunks.append(proc.stderr.read()), daemon=True)
    t_err.start()

    ci = 0
    last_key, last_bytes = None, blank
    sync_lead = 0.09
    try:
        for f in range(total):
            t = f / fps + sync_lead
            while ci < len(cues) and cues[ci]["end"] <= t:
                ci += 1
            cue = cues[ci] if ci < len(cues) and cues[ci]["start"] <= t < cues[ci]["end"] else None
            if cue is None:
                key, data = None, blank
            else:
                key = rnd.state_key(ci, cue, t)
                if key == last_key:
                    data = last_bytes
                else:
                    data = rnd.render(cue, t, band_top, band_h).tobytes()
            last_key, last_bytes = key, data
            proc.stdin.write(data)
            if progress and f % 15 == 0:
                progress(f / total)
        proc.stdin.close()
    except BrokenPipeError:
        pass
    proc.wait()
    t_err.join(timeout=2)
    if proc.returncode != 0:
        msg = b"".join(err_chunks).decode(errors="ignore")[-1500:]
        if quality != "max" and "videotoolbox" in msg.lower():
            # hardware encoder unavailable -> retry in software
            return export_mp4(src, out, cues, style, meta, clean_audio, denoise_live, "max", progress)
        raise RuntimeError(f"ffmpeg failed: {msg}")
    if progress:
        progress(1.0)
