"""
Anonymous Telemetry & Unique Installation Tracker.
Counts active users without requiring user sign-ups or personal information.
Works 100% offline-tolerant (queues/logs locally, sends non-blocking pings if connected).
"""
from __future__ import annotations

import json
import threading
import time
import urllib.request
import uuid
from pathlib import Path

from config import (
    APP_VERSION,
    EDITION,
    INSTALL_ID_FILE,
    TELEMETRY_ENDPOINT,
    get_platform_info,
)

ANALYTICS_FILE = INSTALL_ID_FILE.parent / "analytics.json"

def get_install_id() -> str:
    """Retrieve or create persistent anonymous installation UUID."""
    if INSTALL_ID_FILE.exists():
        try:
            tid = INSTALL_ID_FILE.read_text(encoding="utf-8").strip()
            if tid:
                return tid
        except Exception:
            pass
    tid = str(uuid.uuid4())
    try:
        INSTALL_ID_FILE.write_text(tid, encoding="utf-8")
    except Exception:
        pass
    return tid

def record_launch() -> dict:
    """Update local launch statistics."""
    tid = get_install_id()
    now = time.time()
    stats = {
        "install_id": tid,
        "first_launch": now,
        "last_launch": now,
        "launch_count": 1,
        "edition": EDITION,
        "version": APP_VERSION,
        "platform": get_platform_info(),
        "pings_succeeded": 0,
        "pings_failed": 0,
    }
    if ANALYTICS_FILE.exists():
        try:
            existing = json.loads(ANALYTICS_FILE.read_text(encoding="utf-8"))
            if isinstance(existing, dict):
                stats["first_launch"] = existing.get("first_launch", now)
                stats["launch_count"] = existing.get("launch_count", 0) + 1
                stats["pings_succeeded"] = existing.get("pings_succeeded", 0)
                stats["pings_failed"] = existing.get("pings_failed", 0)
        except Exception:
            pass
    try:
        ANALYTICS_FILE.write_text(json.dumps(stats, indent=2), encoding="utf-8")
    except Exception:
        pass
    return stats

def _send_ping_worker(stats: dict) -> None:
    """Background task to report anonymous launch to telemetry server."""
    if not TELEMETRY_ENDPOINT:
        return
    payload = json.dumps({
        "install_id": stats["install_id"],
        "edition": stats["edition"],
        "version": stats["version"],
        "launch_count": stats["launch_count"],
        "platform": stats["platform"],
        "timestamp": int(stats["last_launch"]),
    }).encode("utf-8")

    try:
        req = urllib.request.Request(
            TELEMETRY_ENDPOINT,
            data=payload,
            headers={
                "Content-Type": "application/json",
                "User-Agent": f"LafziTelemetry/{stats['version']} ({stats['edition']})",
            },
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=4.0) as resp:
            if resp.status in (200, 201, 204):
                stats["pings_succeeded"] = stats.get("pings_succeeded", 0) + 1
            else:
                stats["pings_failed"] = stats.get("pings_failed", 0) + 1
    except Exception:
        # Fails completely silently if user is offline or telemetry server not yet online
        stats["pings_failed"] = stats.get("pings_failed", 0) + 1

    try:
        ANALYTICS_FILE.write_text(json.dumps(stats, indent=2), encoding="utf-8")
    except Exception:
        pass

def track_app_launch() -> None:
    """Triggered on backend startup."""
    try:
        stats = record_launch()
        threading.Thread(target=_send_ping_worker, args=(stats,), daemon=True).start()
    except Exception:
        pass
