"""
Offline transcription for Muftamar with mlx-whisper (Metal / Apple Silicon).

Pipeline
--------
1. Voice-activity detection (ffmpeg silencedetect) -> only speech regions are
   sent to Whisper (`clip_timestamps`). Silent stretches can't hallucinate and
   simply have no captions.
2. Whisper large-v3-turbo with language forced to "hi": Hindustani speech is
   written in Devanagari (which spells vowels -> accurate romanisation) while
   English words stay in Latin script. Turbo was trained without the translate
   task, and forcing the language stops it from switching to English output.
3. Hallucination guards: low temperature fallback only, compression / no-speech
   / confidence filters, repetition collapsing, prompt-leak and known-phrase
   blacklist, and a "second opinion" re-decode of suspicious all-English,
   low-confidence segments (the typical "it translated my Urdu" failure).
4. Word timings are clipped to speech regions so captions never linger over
   silence.
"""
from __future__ import annotations

import json
import os
import re
import threading
import time
import urllib.request
from pathlib import Path
from typing import Callable

os.environ.setdefault("HF_HUB_DISABLE_TELEMETRY", "1")
os.environ.setdefault("HF_HUB_OFFLINE", "1")  # never phone home at runtime

BACKEND_DIR = Path(__file__).resolve().parent
MODELS_DIR = BACKEND_DIR / "models"

MODEL_KEY = "turbo"
MODEL = {
    "id": MODEL_KEY,
    "label": "Offline AI Caption Engine",
    "repo": "mlx-community/whisper-large-v3-turbo",
    "dir": "whisper-large-v3-turbo",
    "files": ["config.json", "weights.safetensors"],
    "size": "1.6 GB",
}

# Short, code-mixed prompt: Devanagari for Urdu, Latin for English words.
# No call-to-action sentences (those are what Whisper "leaks" into silence).
DEFAULT_PROMPT = (
    "हाँ तो दोस्तों, आज की video में हम AI tools और design के बारे में बात करेंगे, "
    "जो actually बहुत ज़रूरी और editable है, इसे तुम आसानी से बनाओगे।"
)
# Pure-Urdu prompt used for the second-opinion pass on suspicious English segments.
URDU_ONLY_PROMPT = "हाँ तो दोस्तों, आज हम इस बारे में बात करेंगे कि ज़िंदगी में क्या ज़रूरी है।"

HALLUCINATION_PATTERNS = [
    r"subtitles? (by|from)", r"amara\.org", r"thanks? (you )?for watching", r"please subscribe",
    r"like (and|&) subscribe", r"उपशीर्षक", r"सब्सक्राइब", r"सबटाइटल", r"www\.", r"\.com\b",
    r"^\W*(धन्यवाद|शुक्रिया|thank you)\W*$", r"^\W*(music|संगीत|♪+)\W*$",
]
_HALL_RE = [re.compile(p, re.I) for p in HALLUCINATION_PATTERNS]
_NOISE_WORDS = {"झाल", "jhaal", "♪", "♫"}
_LATIN_RE = re.compile(r"[A-Za-z]")
_DEV_RE = re.compile(r"[\u0900-\u097F]")


# ---------------------------------------------------------------------------
# Model files + exact-progress downloader
# ---------------------------------------------------------------------------
def model_path() -> Path:
    return MODELS_DIR / MODEL["dir"]


def model_ready() -> bool:
    p = model_path()
    return all((p / f).exists() for f in MODEL["files"])


class DownloadState:
    def __init__(self):
        self.lock = threading.Lock()
        self.status = "idle"          # idle | running | done | error
        self.downloaded = 0
        self.total = 0
        self.speed = 0.0
        self.error = None
        self.started = 0.0

    def snapshot(self) -> dict:
        with self.lock:
            ready = model_ready()
            if ready:
                disk = sum((model_path() / f).stat().st_size for f in MODEL["files"] if (model_path() / f).exists())
                total = self.total or disk
                return {"status": "done", "downloaded": total, "total": total, "percent": 100.0,
                        "speed": 0.0, "eta": 0, "error": None, "model": MODEL["label"], "size": MODEL["size"]}
            pct = (self.downloaded / self.total * 100) if self.total else 0.0
            eta = ((self.total - self.downloaded) / self.speed) if self.speed > 0 and self.total else None
            return {"status": self.status, "downloaded": self.downloaded,
                    "total": self.total, "percent": round(min(pct, 99.9), 1), "speed": round(self.speed, 1),
                    "eta": int(round(eta)) if eta is not None else None, "error": self.error,
                    "model": MODEL["label"], "size": MODEL["size"]}


DOWNLOAD = DownloadState()


def _remote_sizes() -> dict[str, int]:
    url = f"https://huggingface.co/api/models/{MODEL['repo']}/tree/main"
    with urllib.request.urlopen(url, timeout=30) as r:
        tree = json.loads(r.read())
    sizes = {}
    for f in tree:
        if f.get("type") == "file" and f["path"] in MODEL["files"]:
            sizes[f["path"]] = int((f.get("lfs") or {}).get("size") or f.get("size") or 0)
    return sizes


def download_model() -> None:
    """Resumable download with byte-exact progress into DOWNLOAD."""
    st = DOWNLOAD
    with st.lock:
        if st.status == "running":
            return
        st.status, st.error, st.started = "running", None, time.time()
    try:
        dst = model_path()
        dst.mkdir(parents=True, exist_ok=True)
        sizes = _remote_sizes()
        total = sum(sizes.values())
        done_bytes = 0
        for name in MODEL["files"]:
            final = dst / name
            if final.exists() and (not sizes.get(name) or final.stat().st_size == sizes[name]):
                done_bytes += final.stat().st_size
            elif (dst / (name + ".part")).exists():
                done_bytes += (dst / (name + ".part")).stat().st_size
        with st.lock:
            st.total, st.downloaded = total, done_bytes

        window: list[tuple[float, int]] = [(time.time(), done_bytes)]
        for name in MODEL["files"]:
            final = dst / name
            expected = sizes.get(name, 0)
            if final.exists() and (not expected or final.stat().st_size == expected):
                continue
            part = dst / (name + ".part")
            have = part.stat().st_size if part.exists() else 0
            req = urllib.request.Request(f"https://huggingface.co/{MODEL['repo']}/resolve/main/{name}",
                                         headers={"User-Agent": "Muftamar/1.0"})
            if have:
                req.add_header("Range", f"bytes={have}-")
            with urllib.request.urlopen(req, timeout=60) as r:
                if have and r.status != 206:      # server ignored Range -> restart file
                    with st.lock:
                        st.downloaded -= have
                    have = 0
                    part.unlink(missing_ok=True)
                with part.open("ab" if have else "wb") as fh:
                    while True:
                        chunk = r.read(1 << 20)
                        if not chunk:
                            break
                        fh.write(chunk)
                        now = time.time()
                        with st.lock:
                            st.downloaded += len(chunk)
                            window.append((now, st.downloaded))
                            while len(window) > 2 and now - window[0][0] > 4:
                                window.pop(0)
                            dt = now - window[0][0]
                            st.speed = (st.downloaded - window[0][1]) / dt if dt > 0 else 0.0
            if expected and part.stat().st_size != expected:
                raise RuntimeError(f"{name}: incomplete download ({part.stat().st_size}/{expected} bytes)")
            part.replace(final)
        with st.lock:
            st.status, st.downloaded = "done", st.total
    except Exception as e:  # noqa: BLE001
        with st.lock:
            st.status, st.error = "error", str(e)
        raise


# ---------------------------------------------------------------------------
# Model loading (filters checkpoint keys that aren't parameters in this mlx)
# ---------------------------------------------------------------------------
def _safe_load_model(path_or_hf_repo: str, dtype=None):
    import mlx.core as mx
    import mlx.nn as nn
    from mlx.utils import tree_flatten, tree_unflatten
    from mlx_whisper import whisper

    dtype = dtype or mx.float16
    mp = Path(path_or_hf_repo)
    config = json.loads((mp / "config.json").read_text())
    config.pop("model_type", None)
    quantization = config.pop("quantization", None)
    weights = dict(mx.load(str(mp / "weights.safetensors")))
    model = whisper.Whisper(whisper.ModelDimensions(**config), dtype)
    if quantization is not None:
        nn.quantize(model, **quantization,
                    class_predicate=lambda p, m: isinstance(m, (nn.Linear, nn.Embedding)) and f"{p}.scales" in weights)
    valid = {k for k, _ in tree_flatten(model.parameters())}
    model.update(tree_unflatten([(k, v) for k, v in weights.items() if k in valid]))
    mx.eval(model.parameters())
    return model


_lock = threading.Lock()


class _Progress:
    """Stand-in for tqdm.tqdm so we can surface mlx-whisper's progress."""

    callback: Callable[[float], None] | None = None

    def __init__(self, total=None, **_):
        self.total = total or 1
        self.n = 0

    def update(self, n=1):
        self.n += n
        if _Progress.callback:
            _Progress.callback(min(1.0, self.n / self.total))

    def __enter__(self):
        return self

    def __exit__(self, *a):
        return False

    def close(self):
        pass


def _run_whisper(audio: str, prompt: str, clips: list[float] | None, progress=None,
                 whisper_lang: str = "hi") -> dict:
    import mlx_whisper
    import mlx_whisper.load_models as lm
    import sys
    import tqdm as tqdm_mod

    mt_mod = sys.modules.get("mlx_whisper.transcribe")
    if mt_mod is not None:
        mt_mod.load_model = _safe_load_model
    lm.load_model = _safe_load_model

    kwargs = dict(
        path_or_hf_repo=str(model_path()),
        language=whisper_lang,
        task="transcribe",
        word_timestamps=True,
        initial_prompt=prompt,
        condition_on_previous_text=False,
        temperature=(0.0, 0.2, 0.4),
        compression_ratio_threshold=2.4,
        logprob_threshold=-1.0,
        no_speech_threshold=0.6,
        verbose=False,
    )
    if clips:
        kwargs["clip_timestamps"] = clips
    _Progress.callback = progress
    orig = tqdm_mod.tqdm
    tqdm_mod.tqdm = _Progress
    try:
        return mlx_whisper.transcribe(audio, **kwargs)
    finally:
        tqdm_mod.tqdm = orig
        _Progress.callback = None


# ---------------------------------------------------------------------------
# Hallucination filters
# ---------------------------------------------------------------------------
def _norm(s: str) -> str:
    return re.sub(r"[\W_]+", "", s.lower())


def _seg_words(seg: dict) -> list[dict]:
    out = []
    for w in seg.get("words") or []:
        t = (w.get("word") or "").strip()
        if not t:
            continue
        if t.lower().strip(".,!?।") in _NOISE_WORDS:
            continue
        out.append({"src": t, "start": float(w["start"]), "end": float(w["end"]),
                    "conf": round(float(w.get("probability", 1.0)), 3)})
    return out


def _mean_conf(words: list[dict]) -> float:
    return sum(w["conf"] for w in words) / len(words) if words else 0.0


def _is_hallucination(seg: dict, words: list[dict], prompt_norm: str) -> bool:
    text = (seg.get("text") or "").strip()
    if not text or not words:
        return True
    if seg.get("no_speech_prob", 0) > 0.75 and seg.get("avg_logprob", 0) < -0.85:
        return True
    if seg.get("compression_ratio", 0) > 2.6:
        return True
    if any(r.search(text) for r in _HALL_RE):
        return True
    n = _norm(text)
    if len(n) >= 12 and n in prompt_norm:          # prompt leaked into output
        return True
    if len(words) == 1 and words[0]["conf"] < 0.35 and seg.get("no_speech_prob", 0) > 0.45:
        return True
    if _mean_conf(words) < 0.22:
        return True
    return False


def _collapse_repeats(words: list[dict], max_run: int = 2) -> list[dict]:
    out: list[dict] = []
    for w in words:
        k = _norm(w["src"])
        run = 0
        for prev in reversed(out):
            if _norm(prev["src"]) == k:
                run += 1
            else:
                break
        if run < max_run:
            out.append(w)
    # repeated bigram loops ("ki ki baat ki baat ki baat")
    i = 0
    res: list[dict] = []
    while i < len(out):
        if i + 3 < len(out) and _norm(out[i]["src"]) == _norm(out[i + 2]["src"]) \
                and _norm(out[i + 1]["src"]) == _norm(out[i + 3]["src"]) \
                and len(res) >= 2 and _norm(res[-2]["src"]) == _norm(out[i]["src"]):
            i += 2
            continue
        res.append(out[i])
        i += 1
    return res


def _is_suspicious_english(words: list[dict]) -> bool:
    if len(words) < 4:
        return False
    latin = sum(1 for w in words if _LATIN_RE.search(w["src"]) and not _DEV_RE.search(w["src"]))
    return latin / len(words) > 0.9 and _mean_conf(words) < 0.45


def _clip_to_regions(words: list[dict], regions: list[list[float]]) -> list[dict]:
    if not regions:
        return words
    out = []
    for w in words:
        mid = (w["start"] + w["end"]) / 2
        reg = next((r for r in regions if r[0] - 0.25 <= mid <= r[1] + 0.25), None)
        if reg is None:
            continue
        w = dict(w)
        w["start"] = max(w["start"], reg[0] - 0.05)
        w["end"] = min(w["end"], reg[1] + 0.08)
        w["end"] = min(w["end"], w["start"] + 1.4)    # no word lingers over a pause
        if w["end"] - w["start"] < 0.08:
            w["end"] = w["start"] + 0.08
        out.append(w)
    return out


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------
def transcribe(audio: Path, regions: list[list[float]] | None = None, vocab: str = "",
               progress: Callable[[float], None] | None = None,
               lang: str = "ur", script: str = "roman") -> list[dict]:
    """Returns raw words [{src,start,end,conf}] in the chosen language's source script."""
    from languages import get_language

    if not model_ready():
        raise RuntimeError("AI Caption Engine isn't installed yet. Open Muftamar once while online to finish setup.")
    lang_info = get_language(lang)
    whisper_lang = lang_info["whisperNative"] if script == "native" else lang_info["whisperRoman"]
    prompt = vocab.strip() if vocab and vocab.strip() else None
    prompt_norm = _norm(prompt) if prompt else ""

    with _lock:
        result = _run_whisper(str(audio), prompt, None, progress, whisper_lang=whisper_lang)
        words: list[dict] = []
        for seg in result.get("segments", []):
            sw = _seg_words(seg)
            if _is_hallucination(seg, sw, prompt_norm):
                continue
            words.extend(sw)

    words.sort(key=lambda w: w["start"])
    words = _collapse_repeats(words)
    return _clip_to_regions(words, regions or [])
