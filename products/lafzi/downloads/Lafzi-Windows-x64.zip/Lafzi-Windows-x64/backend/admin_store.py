"""
Lafzi Admin Store & Analytics Engine.
Manages:
- Revenue & orders tracking (Lemon Squeezy integration)
- Discount codes with redemption cap limits
- Anonymous user installation telemetry & active device counts
- Software updates & remote version release manifests
- Platform download analytics (macOS Silicon, macOS Intel, Windows)
- License key issuance and hardware-binding registry
"""
from __future__ import annotations

import hashlib
import json
import os
import secrets
import threading
import time
from pathlib import Path
from typing import Any

from config import DATA_DIR

ADMIN_DATA_FILE = DATA_DIR / "admin_store.json"
ADMIN_LOCK = threading.Lock()

DEFAULT_STORE: dict[str, Any] = {
    "settings": {
        "base_price": 2950,
        "currency": "PKR",
        "currency_symbol": "Rs",
        "lemonsqueezy_store_id": os.getenv("LEMONSQUEEZY_STORE_ID", "lafzi"),
        "lemonsqueezy_variant_id": os.getenv("LEMONSQUEEZY_VARIANT_ID", "default"),
        "lemonsqueezy_checkout_url": os.getenv("LEMONSQUEEZY_CHECKOUT_URL", "https://lafzi.lemonsqueezy.com/buy/lafzi-studio"),
        "admin_pin": os.getenv("LAFZI_ADMIN_PIN", "lafzi2025"),
    },
    "updates": {
        "latest_version": "1.0.0",
        "release_notes": "Initial public release of Lafzi & Lafzi Studio with 18 languages, dual Native/Roman script, and GPU acceleration.",
        "release_date": time.time(),
        "mandatory": False,
        "downloads": {
            "macos_arm64": "https://downloads.lafzi.app/v1.0.0/LafziStudio-AppleSilicon.dmg",
            "macos_x86_64": "https://downloads.lafzi.app/v1.0.0/LafziStudio-Intel.dmg",
            "windows_x64": "https://downloads.lafzi.app/v1.0.0/LafziStudio-Windows-x64.zip",
        },
    },
    "discounts": [
        {
            "code": "LAUNCH50",
            "type": "percent",  # 'percent' or 'fixed'
            "value": 50,        # 50% off
            "cap": 100,         # Maximum 100 redemptions
            "used_count": 0,
            "active": True,
            "created_at": time.time(),
            "description": "50% launch discount for early adopters",
        },
        {
            "code": "CREATOR1000",
            "type": "fixed",
            "value": 1000,      # Rs 1,000 flat discount
            "cap": 50,
            "used_count": 0,
            "active": True,
            "created_at": time.time(),
            "description": "Rs 1,000 off for creator community",
        },
    ],
    "orders": [],
    "downloads": {
        "macos_arm64": 0,
        "macos_x86_64": 0,
        "windows_x64": 0,
        "total": 0,
    },
    "licenses": [],
    "installs": {},  # install_id -> install_metadata
}


def _load_store() -> dict[str, Any]:
    if not ADMIN_DATA_FILE.exists():
        _save_store(DEFAULT_STORE)
        return DEFAULT_STORE
    try:
        content = json.loads(ADMIN_DATA_FILE.read_text(encoding="utf-8"))
        if not isinstance(content, dict):
            return DEFAULT_STORE
        # Merge missing top-level keys
        for k, v in DEFAULT_STORE.items():
            if k not in content:
                content[k] = v
        return content
    except Exception:
        return DEFAULT_STORE


def _save_store(data: dict[str, Any]) -> None:
    try:
        ADMIN_DATA_FILE.parent.mkdir(parents=True, exist_ok=True)
        ADMIN_DATA_FILE.write_text(json.dumps(data, indent=2), encoding="utf-8")
    except Exception as e:
        print(f"[AdminStore] Failed to save store: {e}")


# -----------------------------------------------------------------------------
# Telemetry & User Counts
# -----------------------------------------------------------------------------
def record_telemetry_ping(data: dict[str, Any]) -> dict[str, Any]:
    """Record an anonymous launch ping from an app instance."""
    install_id = data.get("install_id")
    if not install_id:
        return {"ok": False, "error": "install_id required"}

    with ADMIN_LOCK:
        store = _load_store()
        installs = store.setdefault("installs", {})
        now = time.time()
        existing = installs.get(install_id)

        if existing:
            existing["last_seen"] = now
            existing["launch_count"] = existing.get("launch_count", 0) + 1
            existing["version"] = data.get("version", existing.get("version"))
            existing["edition"] = data.get("edition", existing.get("edition"))
        else:
            installs[install_id] = {
                "install_id": install_id,
                "first_seen": now,
                "last_seen": now,
                "launch_count": 1,
                "edition": data.get("edition", "base"),
                "version": data.get("version", "1.0.0"),
                "platform": data.get("platform", {}),
            }

        _save_store(store)
        return {"ok": True, "total_users": len(installs)}


# -----------------------------------------------------------------------------
# Download Tracking
# -----------------------------------------------------------------------------
def track_download(platform_key: str) -> dict[str, Any]:
    """Track a platform download click from the landing page."""
    valid_keys = {"macos_arm64", "macos_x86_64", "windows_x64"}
    if platform_key not in valid_keys:
        platform_key = "macos_arm64"

    with ADMIN_LOCK:
        store = _load_store()
        dl = store.setdefault("downloads", {"macos_arm64": 0, "macos_x86_64": 0, "windows_x64": 0, "total": 0})
        dl[platform_key] = dl.get(platform_key, 0) + 1
        dl["total"] = dl.get("total", 0) + 1
        _save_store(store)
        return {"ok": True, "downloads": dl}


# -----------------------------------------------------------------------------
# Software Update Management
# -----------------------------------------------------------------------------
def get_current_update_manifest() -> dict[str, Any]:
    """Return the active software update manifest for apps to check."""
    store = _load_store()
    return store.get("updates", DEFAULT_STORE["updates"])


def publish_update_manifest(
    version: str,
    notes: str,
    mandatory: bool = False,
    downloads: dict[str, str] | None = None,
) -> dict[str, Any]:
    """Publish a new software update for desktop apps."""
    with ADMIN_LOCK:
        store = _load_store()
        cur_downloads = store.get("updates", {}).get("downloads", DEFAULT_STORE["updates"]["downloads"])
        if downloads:
            cur_downloads.update(downloads)

        manifest = {
            "latest_version": version.strip().lstrip("v"),
            "release_notes": notes.strip(),
            "release_date": time.time(),
            "mandatory": bool(mandatory),
            "downloads": cur_downloads,
        }
        store["updates"] = manifest
        _save_store(store)
        return {"ok": True, "manifest": manifest}


# -----------------------------------------------------------------------------
# Discount Codes with Cap Limits
# -----------------------------------------------------------------------------
def list_discounts() -> list[dict[str, Any]]:
    store = _load_store()
    return store.get("discounts", [])


def create_discount_code(
    code: str,
    disc_type: str,
    value: float,
    cap: int = 100,
    description: str = "",
) -> dict[str, Any]:
    code = code.strip().upper()
    if not code:
        return {"ok": False, "error": "Discount code cannot be empty"}
    if disc_type not in ("percent", "fixed"):
        return {"ok": False, "error": "Discount type must be 'percent' or 'fixed'"}
    if value <= 0:
        return {"ok": False, "error": "Value must be greater than 0"}

    with ADMIN_LOCK:
        store = _load_store()
        discounts = store.setdefault("discounts", [])
        for d in discounts:
            if d.get("code") == code:
                return {"ok": False, "error": f"Discount code '{code}' already exists"}

        new_discount = {
            "code": code,
            "type": disc_type,
            "value": value,
            "cap": max(1, int(cap)),
            "used_count": 0,
            "active": True,
            "created_at": time.time(),
            "description": description.strip(),
        }
        discounts.append(new_discount)
        _save_store(store)
        return {"ok": True, "discount": new_discount}


def toggle_discount_code(code: str, active: bool | None = None) -> dict[str, Any]:
    code = code.strip().upper()
    with ADMIN_LOCK:
        store = _load_store()
        for d in store.setdefault("discounts", []):
            if d.get("code") == code:
                d["active"] = not d.get("active", True) if active is None else bool(active)
                _save_store(store)
                return {"ok": True, "code": code, "active": d["active"]}
        return {"ok": False, "error": f"Code '{code}' not found"}


def delete_discount_code(code: str) -> dict[str, Any]:
    code = code.strip().upper()
    with ADMIN_LOCK:
        store = _load_store()
        discounts = store.setdefault("discounts", [])
        original_len = len(discounts)
        store["discounts"] = [d for d in discounts if d.get("code") != code]
        if len(store["discounts"]) == original_len:
            return {"ok": False, "error": f"Code '{code}' not found"}
        _save_store(store)
        return {"ok": True, "deleted": code}


def validate_discount_code(code: str, base_price: float = 2950.0) -> dict[str, Any]:
    """Validate discount code and calculate discounted price."""
    code = code.strip().upper()
    store = _load_store()
    settings = store.get("settings", DEFAULT_STORE["settings"])
    actual_base = float(settings.get("base_price", base_price))

    if not code:
        return {
            "valid": False,
            "error": "Please enter a discount code.",
            "final_price": actual_base,
            "discount_amount": 0,
        }

    for d in store.get("discounts", []):
        if d.get("code") == code:
            if not d.get("active", True):
                return {
                    "valid": False,
                    "error": f"Promo code '{code}' is inactive.",
                    "final_price": actual_base,
                    "discount_amount": 0,
                }
            cap = int(d.get("cap", 100))
            used = int(d.get("used_count", 0))
            if used >= cap:
                return {
                    "valid": False,
                    "error": f"Promo code '{code}' has reached its maximum redemption cap ({cap}/{cap}).",
                    "final_price": actual_base,
                    "discount_amount": 0,
                    "cap_reached": True,
                }

            # Calculate discount
            disc_type = d.get("type", "percent")
            disc_val = float(d.get("value", 0))
            if disc_type == "percent":
                savings = (disc_val / 100.0) * actual_base
            else:
                savings = min(disc_val, actual_base)

            final_price = max(0.0, actual_base - savings)
            remaining_uses = max(0, cap - used)

            return {
                "valid": True,
                "code": code,
                "type": disc_type,
                "value": disc_val,
                "base_price": actual_base,
                "discount_amount": round(savings, 2),
                "final_price": round(final_price, 2),
                "remaining_uses": remaining_uses,
                "cap": cap,
                "used_count": used,
                "currency_symbol": settings.get("currency_symbol", "Rs"),
                "message": f"Code '{code}' applied! You save {settings.get('currency_symbol', 'Rs')} {int(savings):,}.",
            }

    return {
        "valid": False,
        "error": f"Invalid promo code '{code}'.",
        "final_price": actual_base,
        "discount_amount": 0,
    }


def increment_discount_use(code: str) -> bool:
    code = code.strip().upper()
    with ADMIN_LOCK:
        store = _load_store()
        for d in store.setdefault("discounts", []):
            if d.get("code") == code:
                d["used_count"] = d.get("used_count", 0) + 1
                _save_store(store)
                return True
        return False


# -----------------------------------------------------------------------------
# License Generation & Order Processing
# -----------------------------------------------------------------------------
def generate_cryptographic_license(prefix: str = "LAFZI-STU") -> str:
    """Generate authenticated license key with SHA256 checksum."""
    token1 = secrets.token_hex(2).upper()
    token2 = secrets.token_hex(2).upper()
    body = f"{prefix}-{token1}-{token2}"
    chk = hashlib.sha256(f"LAFZI_KEY:{body}".encode("utf-8")).hexdigest()[:6].upper()
    return f"{body}-{chk}"


def issue_license_key(customer_email: str = "", note: str = "") -> dict[str, Any]:
    """Issue a new license key and save to registry."""
    key = generate_cryptographic_license()
    entry = {
        "key": key,
        "email": customer_email.strip().lower(),
        "created_at": time.time(),
        "status": "unused",  # 'unused', 'active', 'revoked'
        "hwid_bound": None,
        "note": note.strip(),
    }
    with ADMIN_LOCK:
        store = _load_store()
        store.setdefault("licenses", []).insert(0, entry)
        _save_store(store)
    return entry


def issue_batch_license_keys(count: int = 5, note: str = "Batch generation") -> list[dict[str, Any]]:
    count = max(1, min(count, 500))
    issued = []
    with ADMIN_LOCK:
        store = _load_store()
        lic_list = store.setdefault("licenses", [])
        now = time.time()
        for _ in range(count):
            k = generate_cryptographic_license()
            item = {
                "key": k,
                "email": "",
                "created_at": now,
                "status": "unused",
                "hwid_bound": None,
                "note": note,
            }
            lic_list.insert(0, item)
            issued.append(item)
        _save_store(store)
    return issued


def revoke_license_key(key: str) -> dict[str, Any]:
    key = key.strip().upper()
    with ADMIN_LOCK:
        store = _load_store()
        for item in store.setdefault("licenses", []):
            if item.get("key") == key:
                item["status"] = "revoked"
                item["revoked_at"] = time.time()
                _save_store(store)
                return {"ok": True, "key": key, "status": "revoked"}
        return {"ok": False, "error": "License key not found"}


def record_order_and_issue_key(
    customer_email: str,
    customer_name: str = "",
    amount: float = 2950.0,
    discount_code: str = "",
    order_id: str = "",
) -> dict[str, Any]:
    """Called when a Lemon Squeezy order is fulfilled."""
    if not order_id:
        order_id = f"LS-{secrets.token_hex(4).upper()}"

    # Increment discount usage if applicable
    if discount_code:
        increment_discount_use(discount_code)

    lic_entry = issue_license_key(customer_email, f"Purchased via Order {order_id}")

    order_entry = {
        "order_id": order_id,
        "customer_name": customer_name.strip() or "Customer",
        "customer_email": customer_email.strip().lower(),
        "amount": float(amount),
        "discount_code": discount_code.strip().upper(),
        "license_key": lic_entry["key"],
        "created_at": time.time(),
        "status": "completed",
    }

    with ADMIN_LOCK:
        store = _load_store()
        store.setdefault("orders", []).insert(0, order_entry)
        _save_store(store)

    return {
        "ok": True,
        "order": order_entry,
        "license_key": lic_entry["key"],
    }


# -----------------------------------------------------------------------------
# Admin Analytics Summary
# -----------------------------------------------------------------------------
def get_admin_metrics() -> dict[str, Any]:
    store = _load_store()
    settings = store.get("settings", DEFAULT_STORE["settings"])
    orders = store.get("orders", [])
    licenses = store.get("licenses", [])
    downloads = store.get("downloads", {"macos_arm64": 0, "macos_x86_64": 0, "windows_x64": 0, "total": 0})
    installs = store.get("installs", {})
    discounts = store.get("discounts", [])
    updates = store.get("updates", DEFAULT_STORE["updates"])

    total_revenue = sum(float(o.get("amount", 0)) for o in orders)
    active_keys = sum(1 for k in licenses if k.get("status") in ("active", "unused"))
    revoked_keys = sum(1 for k in licenses if k.get("status") == "revoked")

    # Installs breakdown
    studio_installs = sum(1 for i in installs.values() if i.get("edition") == "studio")
    base_installs = len(installs) - studio_installs

    return {
        "revenue": {
            "total": round(total_revenue, 2),
            "order_count": len(orders),
            "currency": settings.get("currency", "PKR"),
            "currency_symbol": settings.get("currency_symbol", "Rs"),
            "base_price": settings.get("base_price", 2950),
        },
        "users": {
            "total_installs": len(installs),
            "base_installs": base_installs,
            "studio_installs": studio_installs,
        },
        "downloads": downloads,
        "licenses": {
            "total_issued": len(licenses),
            "active_available": active_keys,
            "revoked": revoked_keys,
        },
        "discounts_count": len(discounts),
        "current_version": updates.get("latest_version", "1.0.0"),
        "recent_orders": orders[:10],
        "recent_licenses": licenses[:15],
        "discounts": discounts,
        "updates": updates,
    }
