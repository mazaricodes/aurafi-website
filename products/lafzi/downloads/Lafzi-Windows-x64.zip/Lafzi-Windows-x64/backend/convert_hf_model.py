"""
Convert a HuggingFace Transformers Whisper checkpoint (`model.safetensors`) into
the layout expected by `mlx-whisper` (`config.json` + `weights.safetensors`),
purely with `mlx.core` (no PyTorch required).
"""
from __future__ import annotations

import base64
import gzip
import json
import re
from pathlib import Path

# Alignment heads for word-level timestamps (from OpenAI / mlx-whisper)
_ALIGNMENT_HEADS = {
    (32, 4): b"ABzY8j^C+e0{>%RARaKHP%t(lGR*)0g!tONPyhe`",  # large-v3-turbo
    (32, 32): b"ABzY8gWO1E0{>%R7(9S+Kn!D~%ngiGaR?*L!iJG9p-nab0JQ=-{D1-g00",  # large-v3
    (12, 12): b"ABzY8DmU6=0{>%Rpa?J`kvJ6qF(V^F86#Xh7JUGMK}P<N0000",  # small
}

_KEY_SUBS = [
    (r"^model\.", ""),
    (r"^encoder\.embed_positions\.weight$", "encoder.positional_embedding"),
    (r"^decoder\.embed_positions\.weight$", "decoder.positional_embedding"),
    (r"^decoder\.embed_tokens\.", "decoder.token_embedding."),
    (r"^encoder\.layer_norm\.", "encoder.ln_post."),
    (r"^decoder\.layer_norm\.", "decoder.ln."),
    (r"\.layers\.", ".blocks."),
    (r"\.self_attn\.", ".attn."),
    (r"\.encoder_attn\.", ".cross_attn."),
    (r"\.self_attn_layer_norm\.", ".attn_ln."),
    (r"\.encoder_attn_layer_norm\.", ".cross_attn_ln."),
    (r"\.final_layer_norm\.", ".mlp_ln."),
    (r"\.q_proj\.", ".query."),
    (r"\.k_proj\.", ".key."),
    (r"\.v_proj\.", ".value."),
    (r"\.out_proj\.", ".out."),
    (r"\.fc1\.", ".mlp1."),
    (r"\.fc2\.", ".mlp2."),
]


def _map_key(k: str) -> str | None:
    if k.startswith(("proj_out.", "model.encoder.embed_positions.")):
        return None
    for pat, rep in _KEY_SUBS:
        k = re.sub(pat, rep, k)
    return k


def convert(hf_repo: str, dst: Path) -> Path:
    import mlx.core as mx
    import numpy as np
    from huggingface_hub import hf_hub_download

    dst.mkdir(parents=True, exist_ok=True)
    cfg_path = hf_hub_download(hf_repo, "config.json")
    st_path = hf_hub_download(hf_repo, "model.safetensors")

    hf_cfg = json.loads(Path(cfg_path).read_text())
    mlx_cfg = {
        "n_mels": hf_cfg.get("num_mel_bins", 128),
        "n_audio_ctx": hf_cfg.get("max_source_positions", 1500),
        "n_audio_state": hf_cfg["d_model"],
        "n_audio_head": hf_cfg["encoder_attention_heads"],
        "n_audio_layer": hf_cfg["encoder_layers"],
        "n_vocab": hf_cfg["vocab_size"],
        "n_text_ctx": hf_cfg.get("max_target_positions", 448),
        "n_text_state": hf_cfg["d_model"],
        "n_text_head": hf_cfg["decoder_attention_heads"],
        "n_text_layer": hf_cfg["decoder_layers"],
        "model_type": "whisper",
    }

    raw = mx.load(st_path)
    out = {}
    for k, v in raw.items():
        nk = _map_key(k)
        if nk is None:
            continue
        if nk in ("encoder.conv1.weight", "encoder.conv2.weight") and v.ndim == 3:
            v = v.transpose(0, 2, 1)
        out[nk] = v.astype(mx.float16)

    ah_b85 = _ALIGNMENT_HEADS.get((mlx_cfg["n_audio_layer"], mlx_cfg["n_text_layer"]))
    if ah_b85:
        bits = np.frombuffer(gzip.decompress(base64.b85decode(ah_b85)), dtype=bool)
        ah = bits.reshape(mlx_cfg["n_text_layer"], mlx_cfg["n_text_head"])
        out["alignment_heads"] = mx.array(np.asarray(np.nonzero(ah)).T)

    mx.save_safetensors(str(dst / "weights.safetensors"), out)
    (dst / "config.json").write_text(json.dumps(mlx_cfg, indent=2))
    return dst
