"""Font registry shared by the preview (served to the browser) and the exporter (Pillow).
Now supports custom user fonts uploaded in Lafzi Studio!
"""
from __future__ import annotations

import json
import struct
import urllib.request
from pathlib import Path

from config import ALLOW_CUSTOM_FONTS, CUSTOM_FONTS_DIR

FONT_DIR = Path(__file__).resolve().parent / "fonts"
CUSTOM_REGISTRY_FILE = CUSTOM_FONTS_DIR / "registry.json"

GF = "https://github.com/google/fonts/raw/main/"

# 24 unique static display/caption fonts — each of the 24 styles has its own dedicated font!
FONTS: dict[str, dict] = {
    "Poppins Black": {"file": "Poppins-Black.ttf", "urls": [GF + "ofl/poppins/Poppins-Black.ttf"]},
    "Poppins Bold": {"file": "Poppins-Bold.ttf", "urls": [GF + "ofl/poppins/Poppins-Bold.ttf"]},
    "Poppins SemiBold": {"file": "Poppins-SemiBold.ttf", "urls": [GF + "ofl/poppins/Poppins-SemiBold.ttf"]},
    "Anton": {"file": "Anton-Regular.ttf", "urls": [GF + "ofl/anton/Anton-Regular.ttf"]},
    "Bangers": {"file": "Bangers-Regular.ttf", "urls": [GF + "ofl/bangers/Bangers-Regular.ttf"]},
    "Luckiest Guy": {"file": "LuckiestGuy-Regular.ttf", "urls": [
        GF + "apache/luckiestguy/LuckiestGuy-Regular.ttf", GF + "ofl/luckiestguy/LuckiestGuy-Regular.ttf"]},
    "Bebas Neue": {"file": "BebasNeue-Regular.ttf", "urls": [GF + "ofl/bebasneue/BebasNeue-Regular.ttf"]},
    "Archivo Black": {"file": "ArchivoBlack-Regular.ttf", "urls": [GF + "ofl/archivoblack/ArchivoBlack-Regular.ttf"]},
    "Titan One": {"file": "TitanOne-Regular.ttf", "urls": [GF + "ofl/titanone/TitanOne-Regular.ttf"]},
    "Permanent Marker": {"file": "PermanentMarker-Regular.ttf", "urls": [
        GF + "apache/permanentmarker/PermanentMarker-Regular.ttf", GF + "ofl/permanentmarker/PermanentMarker-Regular.ttf"]},
    "Paytone One": {"file": "PaytoneOne-Regular.ttf", "urls": [GF + "ofl/paytoneone/PaytoneOne-Regular.ttf"]},
    "Carter One": {"file": "CarterOne-Regular.ttf", "urls": [GF + "ofl/carterone/CarterOne-Regular.ttf"]},
    "Rubik Mono One": {"file": "RubikMonoOne-Regular.ttf", "urls": [GF + "ofl/rubikmonoone/RubikMonoOne-Regular.ttf"]},
    "Russo One": {"file": "RussoOne-Regular.ttf", "urls": [GF + "ofl/russoone/RussoOne-Regular.ttf"]},
    "Changa One": {"file": "ChangaOne-Regular.ttf", "urls": [GF + "ofl/changaone/ChangaOne-Regular.ttf"]},
    "Lilita One": {"file": "LilitaOne-Regular.ttf", "urls": [GF + "ofl/lilitaone/LilitaOne-Regular.ttf"]},
    "Passion One": {"file": "PassionOne-Black.ttf", "urls": [GF + "ofl/passionone/PassionOne-Black.ttf"]},
    "Righteous": {"file": "Righteous-Regular.ttf", "urls": [GF + "ofl/righteous/Righteous-Regular.ttf"]},
    "Boogaloo": {"file": "Boogaloo-Regular.ttf", "urls": [GF + "ofl/boogaloo/Boogaloo-Regular.ttf"]},
    "Fugaz One": {"file": "FugazOne-Regular.ttf", "urls": [GF + "ofl/fugazone/FugazOne-Regular.ttf"]},
    "Alfa Slab One": {"file": "AlfaSlabOne-Regular.ttf", "urls": [GF + "ofl/alfaslabone/AlfaSlabOne-Regular.ttf"]},
    "Caveat Brush": {"file": "CaveatBrush-Regular.ttf", "urls": [GF + "ofl/caveatbrush/CaveatBrush-Regular.ttf"]},
    "Black Ops One": {"file": "BlackOpsOne-Regular.ttf", "urls": [GF + "ofl/blackopsone/BlackOpsOne-Regular.ttf"]},
    "Knewave": {"file": "Knewave-Regular.ttf", "urls": [GF + "ofl/knewave/Knewave-Regular.ttf"]},
}

SYSTEM_FALLBACKS = [
    "/System/Library/Fonts/Supplemental/Arial Black.ttf",
    "/System/Library/Fonts/Supplemental/Arial Bold.ttf",
    "/System/Library/Fonts/Helvetica.ttc",
    "/Library/Fonts/Arial Bold.ttf",
    "C:/Windows/Fonts/arialbd.ttf",
    "C:/Windows/Fonts/arial.ttf",
]

# Native script macOS system fonts so burned-in MP4 exports render Native scripts cleanly
SCRIPT_SYSTEM_FONTS: list[tuple[int, int, list[str]]] = [
    # Arabic / Urdu / Persian / Pashto / Sindhi
    (0x0600, 0x06FF, [
        "/System/Library/Fonts/GeezaPro.ttc",
        "/System/Library/Fonts/Supplemental/Baghdad.ttc",
        "/System/Library/Fonts/Supplemental/Nadeem.ttc",
        "C:/Windows/Fonts/arial.ttf",
    ]),
    # Devanagari (Hindi / Nepali / Marathi)
    (0x0900, 0x097F, [
        "/System/Library/Fonts/Kohinoor.ttc",
        "/System/Library/Fonts/Supplemental/Devanagari Sangam MN.ttc",
        "C:/Windows/Fonts/nirmala.ttf",
    ]),
    # Bengali / Assamese
    (0x0980, 0x09FF, [
        "/System/Library/Fonts/KohinoorBangla.ttc",
        "/System/Library/Fonts/Supplemental/Bangla Sangam MN.ttc",
        "C:/Windows/Fonts/vrinda.ttf",
    ]),
    # Gurmukhi (Punjabi)
    (0x0A00, 0x0A7F, [
        "/System/Library/Fonts/MuktaMahee.ttc",
        "/System/Library/Fonts/Supplemental/Gurmukhi MN.ttc",
        "C:/Windows/Fonts/raavi.ttf",
    ]),
    # Gujarati
    (0x0A80, 0x0AFF, [
        "/System/Library/Fonts/KohinoorGujarati.ttc",
        "/System/Library/Fonts/Supplemental/Gujarati Sangam MN.ttc",
        "C:/Windows/Fonts/shruti.ttf",
    ]),
    # Tamil
    (0x0B80, 0x0BFF, [
        "/System/Library/Fonts/Supplemental/Tamil Sangam MN.ttc",
        "/System/Library/Fonts/Supplemental/Tamil MN.ttc",
        "C:/Windows/Fonts/latha.ttf",
    ]),
    # Telugu
    (0x0C00, 0x0C7F, [
        "/System/Library/Fonts/KohinoorTelugu.ttc",
        "/System/Library/Fonts/Supplemental/Telugu Sangam MN.ttc",
        "C:/Windows/Fonts/gautami.ttf",
    ]),
    # Kannada
    (0x0C80, 0x0CFF, [
        "/System/Library/Fonts/Supplemental/Kannada Sangam MN.ttc",
        "/System/Library/Fonts/Supplemental/Kannada MN.ttc",
        "C:/Windows/Fonts/tunga.ttf",
    ]),
    # Malayalam
    (0x0D00, 0x0D7F, [
        "/System/Library/Fonts/Supplemental/Malayalam Sangam MN.ttc",
        "/System/Library/Fonts/Supplemental/Malayalam MN.ttc",
        "C:/Windows/Fonts/kartika.ttf",
    ]),
]

def extract_font_family_name(file_path: Path) -> str:
    """Extract font family name from TTF / OTF header in pure Python."""
    try:
        with open(file_path, "rb") as f:
            header = f.read(12)
            if len(header) < 12:
                return file_path.stem
            sfnt_version, num_tables = struct.unpack(">4sH", header[:6])
            tables_data = f.read(num_tables * 16)
            name_offset = None
            name_length = None
            for i in range(num_tables):
                chunk = tables_data[i * 16 : (i + 1) * 16]
                tag, check_sum, t_offset, t_length = struct.unpack(">4sIII", chunk)
                if tag == b"name":
                    name_offset = t_offset
                    name_length = t_length
                    break
            if name_offset is not None and name_length is not None:
                f.seek(name_offset)
                name_data = f.read(min(name_length, 32768))
                if len(name_data) >= 6:
                    format_id, count, string_offset = struct.unpack(">HHH", name_data[:6])
                    names = {}
                    for i in range(min(count, 120)):
                        rec_off = 6 + i * 12
                        if rec_off + 12 > len(name_data):
                            break
                        platform_id, encoding_id, language_id, name_id, length, s_offset = struct.unpack(
                            ">HHHHHH", name_data[rec_off : rec_off + 12]
                        )
                        str_start = string_offset + s_offset
                        str_bytes = name_data[str_start : str_start + length]
                        try:
                            if platform_id == 3:  # Windows Unicode
                                val = str_bytes.decode("utf-16-be", errors="ignore")
                            elif platform_id == 1:  # Mac Roman
                                val = str_bytes.decode("latin1", errors="ignore")
                            else:
                                val = str_bytes.decode("utf-8", errors="ignore")
                            val = val.strip("\x00 \t\r\n")
                            if val:
                                names[name_id] = val
                        except Exception:
                            pass
                    # Prefer Full Name (4) or Family (1) or Typographic Family (16)
                    for nid in (4, 1, 16):
                        if nid in names and len(names[nid]) > 1:
                            return names[nid]
    except Exception:
        pass
    clean_stem = file_path.stem.replace("-", " ").replace("_", " ").title()
    return clean_stem

def get_custom_fonts() -> list[dict]:
    """Retrieve all uploaded user fonts."""
    if not CUSTOM_FONTS_DIR.exists():
        return []
    fonts = []
    # Read registry cache if available
    registry = {}
    if CUSTOM_REGISTRY_FILE.exists():
        try:
            registry = json.loads(CUSTOM_REGISTRY_FILE.read_text(encoding="utf-8"))
        except Exception:
            registry = {}

    dirty = False
    for p in sorted(CUSTOM_FONTS_DIR.iterdir()):
        if p.name == "registry.json" or p.name.startswith("."):
            continue
        if p.suffix.lower() in (".ttf", ".otf", ".woff", ".woff2"):
            family = registry.get(p.name)
            if not family:
                family = extract_font_family_name(p)
                registry[p.name] = family
                dirty = True
            fonts.append({
                "family": family,
                "file": p.name,
                "isCustom": True,
                "url": f"/fonts/custom/{p.name}",
            })

    if dirty:
        try:
            CUSTOM_REGISTRY_FILE.write_text(json.dumps(registry, indent=2), encoding="utf-8")
        except Exception:
            pass

    return fonts

def register_custom_font(file_path: Path, original_filename: str) -> dict:
    """Save an uploaded custom font and return its family metadata."""
    if not ALLOW_CUSTOM_FONTS:
        raise PermissionError("Custom font upload is exclusively available in Lafzi Studio.")

    family = extract_font_family_name(file_path)
    # Save to registry cache
    registry = {}
    if CUSTOM_REGISTRY_FILE.exists():
        try:
            registry = json.loads(CUSTOM_REGISTRY_FILE.read_text(encoding="utf-8"))
        except Exception:
            registry = {}
    registry[file_path.name] = family
    try:
        CUSTOM_REGISTRY_FILE.write_text(json.dumps(registry, indent=2), encoding="utf-8")
    except Exception:
        pass

    return {
        "family": family,
        "file": file_path.name,
        "isCustom": True,
        "url": f"/fonts/custom/{file_path.name}",
    }

def ensure_fonts_downloaded() -> None:
    """Download any missing display fonts into FONT_DIR."""
    FONT_DIR.mkdir(parents=True, exist_ok=True)
    for fam, info in FONTS.items():
        dst = FONT_DIR / info["file"]
        if dst.exists() and dst.stat().st_size > 1000:
            continue
        for url in info.get("urls", []):
            try:
                req = urllib.request.Request(url, headers={"User-Agent": "Lafzi/1.0"})
                with urllib.request.urlopen(req, timeout=15) as r:
                    data = r.read()
                if len(data) > 1000:
                    dst.write_bytes(data)
                    break
            except Exception:
                continue

def font_path(family: str) -> str:
    # 1. Check custom uploaded fonts first
    for cf in get_custom_fonts():
        if cf["family"].lower() == family.lower() or cf["file"].lower() == family.lower():
            p = CUSTOM_FONTS_DIR / cf["file"]
            if p.exists():
                return str(p)

    # 2. Check standard built-in fonts
    info = FONTS.get(family)
    if info:
        p = FONT_DIR / info["file"]
        if p.exists():
            return str(p)

    # 3. Check system fallbacks
    for p in SYSTEM_FALLBACKS:
        if Path(p).exists():
            return p
    raise FileNotFoundError(f"No font available for {family!r}; run setup.sh")

def font_path_for_text(family: str, text: str) -> str:
    """Return the display font for Latin/Roman text, or a system script font for Native scripts."""
    for ch in text:
        cp = ord(ch)
        if cp >= 0x0600:
            for lo, hi, candidates in SCRIPT_SYSTEM_FONTS:
                if lo <= cp <= hi:
                    for cand in candidates:
                        if Path(cand).exists():
                            return cand
    return font_path(family)

def available_fonts() -> list[dict]:
    # Built-in fonts
    items = [
        {"family": fam, "file": info["file"], "available": (FONT_DIR / info["file"]).exists(), "isCustom": False}
        for fam, info in FONTS.items()
    ]
    # Custom uploaded fonts
    items.extend(get_custom_fonts())
    return items
