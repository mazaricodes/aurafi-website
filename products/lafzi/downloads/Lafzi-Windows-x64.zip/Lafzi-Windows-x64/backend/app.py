"""
Lafzi — 100% Offline Multi-Language Native & Roman Desi Captions Studio (Apple Silicon / Metal).

Run:  ./start.sh   (or: cd backend && ../.venv/bin/uvicorn app:app --port 8765)
"""
from __future__ import annotations

import json
import shutil
import subprocess
import threading
import time
import traceback
import uuid
import platform
import webbrowser
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

from fastapi import Body, FastAPI, File, HTTPException, UploadFile
from fastapi.responses import FileResponse, JSONResponse, PlainTextResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

import captions as cap
import config
import custom_styles
import license
import media
import telemetry
import transcribe as tr
import updater
from exporter import export_mp4
from fonts import (
    FONT_DIR,
    available_fonts,
    ensure_fonts_downloaded,
    register_custom_font,
)
from languages import LANGUAGES, get_language
from renderer import DEFAULT_STYLE
from translit import Transliterator

ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / "data"
PROJECTS = DATA / "projects"
DICT_FILE = DATA / "dictionary.json"
FRONTEND_DIST = ROOT / "frontend" / "dist"
PROJECTS.mkdir(parents=True, exist_ok=True)

app = FastAPI(title="Lafzi — Desi Captions Studio")


def _ensure_model_installing() -> dict:
    if not tr.model_ready() and tr.DOWNLOAD.status not in ("running", "done"):
        threading.Thread(target=tr.download_model, daemon=True).start()
    return tr.DOWNLOAD.snapshot()


@app.on_event("startup")
def _on_startup() -> None:
    telemetry.track_app_launch()
    threading.Thread(target=ensure_fonts_downloaded, daemon=True).start()
    if not tr.model_ready():
        threading.Thread(target=tr.download_model, daemon=True).start()
    for d in PROJECTS.iterdir():
        if (d / "project.json").exists():
            try:
                retransliterate(d.name)
            except Exception:  # noqa: BLE001
                pass


# ------------------------------------------------------------------ storage
_io_lock = threading.RLock()


def pdir(pid: str) -> Path:
    d = PROJECTS / pid
    if not d.is_dir() or "/" in pid or ".." in pid:
        raise HTTPException(404, "project not found")
    return d


def load(pid: str) -> dict:
    with _io_lock:
        return json.loads((pdir(pid) / "project.json").read_text())


def save(p: dict) -> dict:
    with _io_lock:
        p["updatedAt"] = time.time()
        path = PROJECTS / p["id"] / "project.json"
        tmp = path.with_suffix(".tmp")
        tmp.write_text(json.dumps(p, ensure_ascii=False))
        tmp.replace(path)
    return p


def patch(pid: str, **kw) -> dict:
    with _io_lock:
        p = load(pid)
        p.update(kw)
        return save(p)


def load_dict() -> list[dict]:
    if DICT_FILE.exists():
        return json.loads(DICT_FILE.read_text())
    return []


def translit() -> Transliterator:
    return Transliterator({e["from"]: e["to"] for e in load_dict() if e.get("from") and e.get("to")})


# --------------------------------------------------------------------- jobs
JOBS: dict[str, dict] = {}
_pool = ThreadPoolExecutor(max_workers=1)  # heavy work is serialised (8 GB RAM friendly)


def submit(pid: str, kind: str, fn, *args) -> dict:
    jid = uuid.uuid4().hex[:10]
    job = {"id": jid, "projectId": pid, "kind": kind, "status": "queued", "progress": 0.0,
           "message": "Waiting in queue...", "result": None, "error": None, "startedAt": time.time()}
    JOBS[jid] = job

    def runner():
        job["status"] = "running"
        try:
            job["result"] = fn(job, *args)
            job["status"] = "done"
            job["progress"] = 1.0
        except Exception as e:  # noqa: BLE001
            traceback.print_exc()
            job["status"] = "error"
            job["error"] = str(e)
            job["message"] = f"Failed: {e}"
        finally:
            job["finishedAt"] = time.time()

    _pool.submit(runner)
    return job


def active_jobs(pid: str) -> list[dict]:
    return [j for j in JOBS.values() if j["projectId"] == pid and j["status"] in ("queued", "running")]


# --------------------------------------------------------- health & model
@app.get("/api/health")
def health():
    return {"ok": True, "edition": config.EDITION, "model": tr.DOWNLOAD.snapshot()}


@app.get("/api/config")
def app_config():
    return config.get_public_config()


@app.get("/api/update/check")
def check_update():
    return updater.check_for_updates()


class LicenseActivateReq(BaseModel):
    key: str
    email: str = ""


@app.get("/api/license/status")
def license_status():
    return license.get_license_status()


@app.post("/api/license/activate")
def license_activate(req: LicenseActivateReq):
    return license.activate_license(req.key, req.email)


@app.post("/api/license/deactivate")
def license_deactivate():
    return license.deactivate_license()


@app.get("/api/model/status")
def model_status():
    return tr.DOWNLOAD.snapshot()


@app.post("/api/model/install")
def model_install():
    return _ensure_model_installing()


# ----------------------------------------------------------------- projects
@app.get("/api/projects")
def list_projects():
    out = []
    for d in sorted(PROJECTS.iterdir(), key=lambda x: x.stat().st_mtime, reverse=True):
        f = d / "project.json"
        if f.exists():
            p = json.loads(f.read_text())
            out.append({k: p.get(k) for k in ("id", "name", "createdAt", "updatedAt", "meta", "status")}
                       | {"hasThumb": (d / "thumb.jpg").exists(), "cueCount": len(p.get("cues") or [])})
    return out


@app.post("/api/projects")
async def create_project(file: UploadFile = File(...)):
    pid = uuid.uuid4().hex[:12]
    d = PROJECTS / pid
    d.mkdir(parents=True)
    ext = Path(file.filename or "video.mp4").suffix.lower() or ".mp4"
    src = d / f"source{ext}"
    with src.open("wb") as fh:
        while chunk := await file.read(1 << 20):
            fh.write(chunk)
    try:
        meta = media.probe(src)
    except Exception as e:  # noqa: BLE001
        shutil.rmtree(d, ignore_errors=True)
        raise HTTPException(400, f"Could not read this file: {e}") from e
    if not meta["hasAudio"]:
        shutil.rmtree(d, ignore_errors=True)
        raise HTTPException(400, "This file has no audio track to caption.")

    # Duration cap check for Base Edition
    if config.MAX_DURATION_SECONDS is not None and meta.get("duration", 0) > config.MAX_DURATION_SECONDS:
        shutil.rmtree(d, ignore_errors=True)
        raise HTTPException(
            403,
            detail={
                "upgrade_required": True,
                "feature": "duration_cap",
                "duration": meta.get("duration", 0),
                "max_duration": config.MAX_DURATION_SECONDS,
                "message": f"Free Lafzi is capped at {int(config.MAX_DURATION_SECONDS)}s video length. Upgrade to Lafzi Studio for unlimited duration!",
            },
        )

    p = {"id": pid, "name": Path(file.filename or "Untitled").stem, "createdAt": time.time(),
         "source": src.name, "playable": src.name, "meta": meta, "status": "preparing",
         "cues": [], "style": dict(DEFAULT_STYLE), "hasCleanAudio": False, "exports": []}
    save(p)

    def prepare(job):
        job["message"] = "Extracting audio..."
        media.extract_audio(src, d / "audio16k.wav")
        try:
            peaks = media.compute_waveform(d / "audio16k.wav", 360)
            (d / "waveform.json").write_text(json.dumps({"peaks": peaks}))
        except Exception:
            pass
        if meta["hasVideo"]:
            media.thumbnail(src, d / "thumb.jpg", min(1.0, meta["duration"] / 3))
        if media.needs_proxy(src, meta):
            job["message"] = "Creating browser preview..."
            media.make_proxy(src, d / "preview.mp4")
            patch(pid, playable="preview.mp4")
        patch(pid, status="new")

    submit(pid, "prepare", prepare)
    return p


@app.get("/api/projects/{pid}")
def get_project(pid: str):
    p = load(pid)
    p["jobs"] = active_jobs(pid)
    return p


@app.delete("/api/projects/{pid}")
def delete_project(pid: str):
    shutil.rmtree(pdir(pid))
    return {"ok": True}


class ProjectUpdate(BaseModel):
    name: str | None = None
    cues: list[dict] | None = None
    style: dict | None = None
    language: str | None = None
    script: str | None = None


@app.put("/api/projects/{pid}")
def update_project(pid: str, body: ProjectUpdate):
    upd = {k: v for k, v in body.model_dump().items() if v is not None}
    return patch(pid, **upd)


@app.get("/api/projects/{pid}/media")
def project_media(pid: str):
    p = load(pid)
    return FileResponse(pdir(pid) / p["playable"])


@app.get("/api/projects/{pid}/waveform")
def project_waveform(pid: str):
    d = pdir(pid)
    wf_file = d / "waveform.json"
    if wf_file.exists():
        try:
            return json.loads(wf_file.read_text())
        except Exception:
            pass
    audio = d / "audio16k.wav"
    if not audio.exists():
        p = load(pid)
        src = d / p["source"]
        if src.exists():
            media.extract_audio(src, audio)
    peaks = media.compute_waveform(audio, 360)
    try:
        wf_file.write_text(json.dumps({"peaks": peaks}))
    except Exception:
        pass
    return {"peaks": peaks}


@app.get("/api/projects/{pid}/thumb")
def project_thumb(pid: str):
    f = pdir(pid) / "thumb.jpg"
    if not f.exists():
        raise HTTPException(404)
    return FileResponse(f)


@app.get("/api/projects/{pid}/clean-audio")
def project_clean_audio(pid: str):
    f = pdir(pid) / "audio_clean.wav"
    if not f.exists():
        raise HTTPException(404, "no cleaned audio yet")
    return FileResponse(f, media_type="audio/wav")


# ------------------------------------------------------------- transcribe
class TranscribeReq(BaseModel):
    useCleanAudio: bool = False
    vocab: str = ""
    wordsPerCaption: int = 3
    language: str = "ur"
    script: str = "roman"


@app.post("/api/projects/{pid}/transcribe")
def start_transcribe(pid: str, req: TranscribeReq):
    d = pdir(pid)
    lang_code = req.language or "ur"
    script_mode = req.script if req.script in ("native", "roman") else "roman"
    lang_info = get_language(lang_code)
    patch(pid, status="transcribing", language=lang_code, script=script_mode)

    def work(job):
        if not tr.model_ready():
            job["message"] = f"Installing {tr.MODEL['label']} ({tr.MODEL['size']})..."
            tr.download_model()
        p_cur = load(pid)
        audio = d / "audio16k.wav"
        if not audio.exists():
            media.extract_audio(d / p_cur["source"], audio)
        if req.useCleanAudio:
            clean = d / "audio_clean.wav"
            if not clean.exists():
                job["message"] = "Cleaning background noise..."
                media.denoise_audio(d / p_cur["source"], clean)
                patch(pid, hasCleanAudio=True)
            audio = d / "audio16k_clean.wav"
            media.extract_audio(clean, audio)

        job["message"] = "Analyzing audio..."
        job["progress"] = 0.04
        duration = float((p_cur.get("meta") or {}).get("duration") or 0.0)
        regions = media.detect_speech_regions(audio, duration)
        if not regions:
            patch(pid, cues=[], status="ready", mode="devanagari", language=lang_code, script=script_mode)
            return {"cues": 0, "words": 0}

        label_str = f"{lang_info['name']} ({'Native' if script_mode == 'native' else 'Roman'})"
        job["message"] = f"Generating captions in {label_str}..."
        t0 = time.time()

        def prog(f):
            job["progress"] = round(0.06 + 0.92 * f, 3)
            job["message"] = f"Generating captions ({label_str})... {int(f * 100)}%"

        try:
            raw = tr.transcribe(audio, regions, req.vocab, prog, lang=lang_code, script=script_mode)
        except Exception:
            patch(pid, status="new" if not load(pid).get("cues") else "ready")
            raise

        tl = translit()
        words = []
        for w in raw:
            text = tl.convert(w["src"], lang=lang_code, script=script_mode).strip()
            if not text:
                continue
            # Deduplicate immediate cross-script boundary repeats
            norm_cur = "".join(ch for ch in text.lower() if ch.isalnum())
            if words:
                norm_prev = "".join(ch for ch in words[-1]["text"].lower() if ch.isalnum())
                if norm_cur and norm_cur == norm_prev and (w["start"] - words[-1]["end"]) < 0.35:
                    words[-1]["end"] = max(words[-1]["end"], w["end"])
                    continue
            words.append({"text": text, "src": w["src"], "start": w["start"], "end": w["end"], "conf": w["conf"]})

        cues = cap.chunk_words(words, req.wordsPerCaption)
        p = load(pid)
        style = {**p.get("style", {}), "wordsPerCaption": req.wordsPerCaption}
        patch(pid, cues=cues, style=style, status="ready", mode="devanagari",
              language=lang_code, script=script_mode,
              transcribe={"model": tr.MODEL["label"], "seconds": round(time.time() - t0, 1),
                          "useCleanAudio": req.useCleanAudio, "speechRegions": len(regions),
                          "language": lang_code, "script": script_mode})
        return {"cues": len(cues), "words": len(words)}

    return submit(pid, "transcribe", work)


@app.get("/api/jobs/{jid}")
def get_job(jid: str):
    j = JOBS.get(jid)
    if not j:
        raise HTTPException(404)
    return j


class RechunkReq(BaseModel):
    wordsPerCaption: int = 3


@app.post("/api/projects/{pid}/rechunk")
def rechunk(pid: str, req: RechunkReq):
    p = load(pid)
    cues = cap.chunk_words(cap.flatten(p.get("cues") or []), req.wordsPerCaption)
    return patch(pid, cues=cues, style={**p.get("style", {}), "wordsPerCaption": req.wordsPerCaption})


class RetranslitReq(BaseModel):
    language: str | None = None
    script: str | None = None


@app.post("/api/projects/{pid}/retransliterate")
def retransliterate(pid: str, req: RetranslitReq | None = Body(default=None)):
    """Re-apply lexicon + custom dictionary + script mode ('native' or 'roman') to every word."""
    p = load(pid)
    tl = translit()
    r = req if isinstance(req, RetranslitReq) else None
    lang_code = (r.language if r and r.language else None) or p.get("language") or "ur"
    script_mode = (r.script if r and r.script in ("native", "roman") else None) or p.get("script") or "roman"
    prev_norm = ""
    prev_end = -10.0
    for c in p.get("cues") or []:
        cleaned_words = []
        for w in c["words"]:
            if not w.get("src") and not w.get("edited"):
                continue
            src_tok = (w.get("src") or w.get("text") or "").strip()
            if src_tok.lower().strip(".,!?।") in ("झाल", "jhaal"):
                continue
            if w.get("edited") and not (r and r.script):
                w["text"] = tl.apply_roman_prefs(w["text"]) if script_mode == "roman" else w["text"]
            else:
                w["text"] = tl.convert(src_tok, lang=lang_code, script=script_mode)
            norm_cur = "".join(ch for ch in w["text"].lower() if ch.isalnum())
            if norm_cur and norm_cur == prev_norm and (w["start"] - prev_end) < 0.35:
                prev_end = max(prev_end, w["end"])
                continue
            prev_norm = norm_cur
            prev_end = w["end"]
            cleaned_words.append(w)
        c["words"] = cleaned_words
    return patch(pid, language=lang_code, script=script_mode,
                 cues=[c for c in (p.get("cues") or []) if c.get("words")])


# ------------------------------------------------------------- audio clean
@app.post("/api/projects/{pid}/denoise")
def start_denoise(pid: str):
    if not config.ALLOW_DENOISE:
        raise HTTPException(
            403,
            detail={
                "upgrade_required": True,
                "feature": "clean_audio",
                "message": "Clean background noise is an exclusive Lafzi Studio feature. Upgrade to unlock crisp, studio-grade vocal isolation!",
            },
        )
    if config.IS_STUDIO and not config.is_studio_licensed():
        lic = license.get_license_status()
        raise HTTPException(
            403,
            detail={
                "license_required": True,
                "feature": "clean_audio",
                "message": "Lafzi Studio license activation required to use AI Voice Noise Isolation.",
                "machine_id": lic.get("machine_id"),
            },
        )
    d = pdir(pid)

    def work(job):
        job["message"] = "Removing background noise..."
        media.denoise_audio(d / load(pid)["source"], d / "audio_clean.wav")
        patch(pid, hasCleanAudio=True)
        return {"ok": True}

    return submit(pid, "denoise", work)


# ------------------------------------------------------------------ export
class ExportReq(BaseModel):
    format: str = "mp4"          # mp4 | srt | vtt | ass | txt
    useCleanAudio: bool = False
    quality: str = "high"        # standard | high | max
    styled: bool = False         # apply uppercase/punctuation style to text formats


@app.post("/api/projects/{pid}/export")
def export(pid: str, req: ExportReq):
    # Strict Lock: Unactivated Lafzi Studio cannot export videos or subtitles
    if config.IS_STUDIO and not config.is_studio_licensed():
        lic = license.get_license_status()
        raise HTTPException(
            403,
            detail={
                "license_required": True,
                "feature": "studio_license",
                "message": "Lafzi Studio license activation required. Please enter your valid license key to export videos.",
                "machine_id": lic.get("machine_id"),
            },
        )

    if req.format in ("srt", "vtt", "ass", "txt") and not config.ALLOW_SUBTITLE_EXPORTS:
        raise HTTPException(
            403,
            detail={
                "upgrade_required": True,
                "feature": "subtitle_exports",
                "message": "Exporting subtitle & transcript files (.srt, .vtt, .ass, .txt) is available in Lafzi Studio.",
            },
        )
    p = load(pid)
    d = pdir(pid)
    cues = p.get("cues") or []
    style = {**DEFAULT_STYLE, **p.get("style", {})}
    safe = "".join(ch for ch in p["name"] if ch.isalnum() or ch in "-_ ").strip().replace(" ", "_") or "captions"
    exp_dir = d / "exports"
    exp_dir.mkdir(exist_ok=True)
    meta = p["meta"]
    st = style if req.styled else None
    if req.format in ("srt", "vtt", "ass", "txt"):
        if req.format == "srt":
            body = cap.to_srt(cues, st)
        elif req.format == "vtt":
            body = cap.to_vtt(cues, st)
        elif req.format == "ass":
            body = cap.to_ass(cues, style, meta["width"] or 1920, meta["height"] or 1080)
        else:
            body = "\n".join(cap.cue_text(c, st) for c in cues)
        name = f"{safe}.{req.format}"
        (exp_dir / name).write_text(body, encoding="utf-8")
        return {"status": "done", "file": name, "url": f"/api/projects/{pid}/exports/{name}"}
    if req.format != "mp4":
        raise HTTPException(400, "unknown format")
    if not meta["hasVideo"]:
        raise HTTPException(400, "Audio-only project: export SRT/VTT/ASS instead.")
    name = f"{safe}_lafzi.mp4"

    def work(job):
        job["message"] = "Rendering captions..."
        clean = d / "audio_clean.wav" if req.useCleanAudio else None
        if req.useCleanAudio and not clean.exists():
            job["message"] = "Cleaning audio..."
            media.denoise_audio(d / p["source"], clean)
            patch(pid, hasCleanAudio=True)

        def prog(f):
            job["progress"] = round(f, 3)
            job["message"] = f"Rendering video... {int(f * 100)}%"

        export_mp4(d / p["source"], exp_dir / name, cues, style, meta, clean, False, req.quality, prog)
        return {"file": name, "url": f"/api/projects/{pid}/exports/{name}"}

    return submit(pid, "export", work)


@app.get("/api/projects/{pid}/exports/{name}")
def download_export(pid: str, name: str):
    f = pdir(pid) / "exports" / Path(name).name
    if not f.exists():
        raise HTTPException(404)
    return FileResponse(f, filename=f.name)


@app.post("/api/projects/{pid}/exports/{name}/reveal")
def reveal_export(pid: str, name: str):
    """Copy exported file to ~/Downloads and reveal it in macOS Finder."""
    f = pdir(pid) / "exports" / Path(name).name
    if not f.exists():
        raise HTTPException(404)
    downloads = Path.home() / "Downloads"
    downloads.mkdir(exist_ok=True)
    dst = downloads / f.name
    shutil.copy2(f, dst)
    try:
        subprocess.run(["open", "-R", str(dst)], check=False)
    except Exception:
        pass
    return {"ok": True, "savedTo": str(dst)}


class OpenExternalUrlReq(BaseModel):
    url: str


@app.post("/api/open-external")
def open_external_url(body: OpenExternalUrlReq):
    """Open an external URL in the system's default browser."""
    target = body.url.strip()
    if not (target.startswith("http://") or target.startswith("https://")):
        raise HTTPException(400, "Invalid URL scheme")
    try:
        webbrowser.open(target)
    except Exception:
        if platform.system() == "Darwin":
            subprocess.run(["open", target], check=False)
        elif platform.system() == "Windows":
            subprocess.run(["start", target], shell=True, check=False)
    return {"ok": True, "opened": target}


# --------------------------------------------------------- dictionary etc.
@app.get("/api/languages")
def get_languages():
    return LANGUAGES


@app.get("/api/dictionary")
def get_dictionary():
    return load_dict()


@app.put("/api/dictionary")
def put_dictionary(entries: list[dict]):
    clean = [{"from": e.get("from", "").strip(), "to": e.get("to", "").strip()}
             for e in entries if e.get("from", "").strip() and e.get("to", "").strip()]
    DICT_FILE.write_text(json.dumps(clean, ensure_ascii=False, indent=1))
    return clean


class TranslitReq(BaseModel):
    text: str
    language: str = "ur"
    script: str = "roman"


@app.post("/api/transliterate")
def transliterate_text(req: TranslitReq):
    return {"roman": translit().text(req.text, lang=req.language, script=req.script)}


# --------------------------------------------------------- custom styles
class CustomStyleCreateReq(BaseModel):
    name: str
    style: dict


@app.get("/api/custom-styles")
def get_custom_styles():
    return custom_styles.list_custom_styles()


@app.post("/api/custom-styles")
def create_custom_style(body: CustomStyleCreateReq):
    if not config.ALLOW_CUSTOM_STYLES:
        raise HTTPException(
            403,
            detail={
                "upgrade_required": True,
                "feature": "custom_styles",
                "message": "Saving custom caption styles is a Lafzi Studio feature. Upgrade to unlock custom style presets!",
            },
        )
    if config.IS_STUDIO and not config.is_studio_licensed():
        lic = license.get_license_status()
        raise HTTPException(
            403,
            detail={
                "license_required": True,
                "feature": "custom_styles",
                "message": "Lafzi Studio license activation required to save custom caption styles.",
                "machine_id": lic.get("machine_id"),
            },
        )
    return custom_styles.save_custom_style(body.name, body.style)


@app.delete("/api/custom-styles/{sid}")
def delete_custom_style(sid: str):
    if not config.ALLOW_CUSTOM_STYLES:
        raise HTTPException(403, detail="Custom styles are disabled in Base edition.")
    ok = custom_styles.delete_custom_style(sid)
    if not ok:
        raise HTTPException(404, "Custom style not found")
    return {"ok": True}


# --------------------------------------------------------- custom fonts
@app.post("/api/fonts/upload")
async def upload_custom_font(file: UploadFile = File(...)):
    if not config.ALLOW_CUSTOM_FONTS:
        raise HTTPException(
            403,
            detail={
                "upgrade_required": True,
                "feature": "custom_fonts",
                "message": "Custom font upload is exclusively available in Lafzi Studio. Upgrade to use your own branding and fonts!",
            },
        )
    if config.IS_STUDIO and not config.is_studio_licensed():
        lic = license.get_license_status()
        raise HTTPException(
            403,
            detail={
                "license_required": True,
                "feature": "custom_fonts",
                "message": "Lafzi Studio license activation required to upload custom fonts.",
                "machine_id": lic.get("machine_id"),
            },
        )
    ext = Path(file.filename or "").suffix.lower()
    if ext not in (".ttf", ".otf", ".woff", ".woff2"):
        raise HTTPException(400, detail="Only .ttf, .otf, .woff, and .woff2 font files are supported.")

    clean_name = "".join(c for c in Path(file.filename).name if c.isalnum() or c in ".-_")
    dest = config.CUSTOM_FONTS_DIR / clean_name
    with dest.open("wb") as fh:
        while chunk := await file.read(1 << 20):
            fh.write(chunk)
    reg = register_custom_font(dest, file.filename)
    return reg


@app.get("/api/fonts")
def fonts():
    return available_fonts()


@app.get("/api/defaults")
def defaults():
    return {"style": DEFAULT_STYLE, "prompt": tr.DEFAULT_PROMPT, "languages": LANGUAGES}


FONT_DIR.mkdir(exist_ok=True)
app.mount("/fonts", StaticFiles(directory=FONT_DIR), name="fonts")

config.CUSTOM_FONTS_DIR.mkdir(parents=True, exist_ok=True)
app.mount("/fonts/custom", StaticFiles(directory=config.CUSTOM_FONTS_DIR), name="custom_fonts")

LANDING_DIR = ROOT / "landing"
if LANDING_DIR.exists():
    app.mount("/landing", StaticFiles(directory=LANDING_DIR, html=True), name="landing")

import admin_store


# --------------------------------------------------------- public analytics & manifest
@app.get("/api/version.json")
def get_version_manifest():
    return admin_store.get_current_update_manifest()


@app.post("/api/telemetry")
def receive_telemetry(payload: dict = Body(...)):
    return admin_store.record_telemetry_ping(payload)


class TrackDownloadReq(BaseModel):
    platform: str = "macos_arm64"


@app.post("/api/downloads/track")
def track_download_click(body: TrackDownloadReq):
    return admin_store.track_download(body.platform)


class ValidateDiscountReq(BaseModel):
    code: str
    base_price: float = 2950.0


@app.post("/api/discounts/validate")
def validate_discount(body: ValidateDiscountReq):
    return admin_store.validate_discount_code(body.code, body.base_price)


# --------------------------------------------------------- Lemon Squeezy Webhook
@app.post("/api/webhooks/lemonsqueezy")
async def lemonsqueezy_webhook(payload: dict = Body(...)):
    """Receives Lemon Squeezy order notifications and automatically generates license key."""
    event_name = payload.get("meta", {}).get("event_name") or payload.get("event") or ""
    data = payload.get("data", {}).get("attributes", {})
    if "order_created" in event_name or event_name == "order_created" or not event_name:
        user_email = data.get("user_email") or payload.get("user_email") or "customer@example.com"
        user_name = data.get("user_name") or payload.get("user_name") or "Valued Creator"
        total = float(data.get("total") or payload.get("total") or 2950)
        discount_code = str(data.get("discount_code") or payload.get("discount_code") or "")
        order_num = str(data.get("first_order_item", {}).get("order_id") or payload.get("order_id") or "")
        return admin_store.record_order_and_issue_key(user_email, user_name, total, discount_code, order_num)
    return {"ok": True, "ignored": event_name}


# --------------------------------------------------------- Admin Portal API
@app.get("/api/admin/metrics")
def admin_metrics():
    return admin_store.get_admin_metrics()


class PublishUpdateReq(BaseModel):
    version: str
    release_notes: str
    mandatory: bool = False
    downloads: dict[str, str] | None = None


@app.post("/api/admin/updates/publish")
def admin_publish_update(body: PublishUpdateReq):
    return admin_store.publish_update_manifest(body.version, body.release_notes, body.mandatory, body.downloads)


class CreateDiscountReq(BaseModel):
    code: str
    type: str = "percent"  # percent | fixed
    value: float
    cap: int = 100
    description: str = ""


@app.get("/api/admin/discounts")
def admin_get_discounts():
    return admin_store.list_discounts()


@app.post("/api/admin/discounts")
def admin_create_discount(body: CreateDiscountReq):
    return admin_store.create_discount_code(body.code, body.type, body.value, body.cap, body.description)


@app.post("/api/admin/discounts/{code}/toggle")
def admin_toggle_discount(code: str):
    return admin_store.toggle_discount_code(code)


@app.delete("/api/admin/discounts/{code}")
def admin_delete_discount(code: str):
    return admin_store.delete_discount_code(code)


class GenerateLicenseReq(BaseModel):
    count: int = 1
    note: str = ""


@app.get("/api/admin/licenses")
def admin_get_licenses():
    return admin_store._load_store().get("licenses", [])


@app.post("/api/admin/licenses/generate")
def admin_generate_licenses(body: GenerateLicenseReq):
    return admin_store.issue_batch_license_keys(body.count, body.note)


@app.post("/api/admin/licenses/{key}/revoke")
def admin_revoke_license(key: str):
    return admin_store.revoke_license_key(key)


class TestPurchaseReq(BaseModel):
    customer_email: str = "creator@example.com"
    customer_name: str = "Hamza Ali"
    amount: float = 2950.0
    discount_code: str = ""


@app.post("/api/admin/test-purchase")
def admin_test_purchase(body: TestPurchaseReq):
    """Dev simulator for Lemon Squeezy purchase without real payment."""
    return admin_store.record_order_and_issue_key(
        body.customer_email,
        body.customer_name,
        body.amount,
        body.discount_code,
    )


@app.get("/admin")
@app.get("/admin/")
@app.get("/admin.html")
def admin_portal_redirect():
    return RedirectResponse(url="/landing/admin.html", status_code=307)


@app.get("/admin.css")
def admin_css_direct():
    f = ROOT / "landing" / "admin.css"
    if f.exists():
        return FileResponse(f, media_type="text/css")
    raise HTTPException(404)


@app.get("/admin.js")
def admin_js_direct():
    f = ROOT / "landing" / "admin.js"
    if f.exists():
        return FileResponse(f, media_type="application/javascript")
    raise HTTPException(404)

if FRONTEND_DIST.exists():
    app.mount("/assets", StaticFiles(directory=FRONTEND_DIST / "assets"), name="assets")

    @app.get("/{path:path}")
    def spa(path: str):
        f = FRONTEND_DIST / path
        if path and f.is_file():
            return FileResponse(f)
        return FileResponse(FRONTEND_DIST / "index.html")
else:
    @app.get("/")
    def no_ui():
        return PlainTextResponse("Frontend not built. Run: cd frontend && npm install && npm run build")


@app.exception_handler(Exception)
async def unhandled(_, exc: Exception):
    return JSONResponse({"detail": str(exc)}, status_code=500)
