"""
Software Update System for Lafzi & Lafzi Studio.
Checks remote release manifest to notify users of available software updates.
"""
from __future__ import annotations

import json
import urllib.request
from typing import Any

from config import APP_VERSION, EDITION, UPDATE_CHECK_URL, get_platform_info

def parse_semver(v: str) -> tuple[int, ...]:
    clean = v.strip().lstrip("v").split("-")[0]
    parts = []
    for p in clean.split("."):
        try:
            parts.append(int(p))
        except ValueError:
            parts.append(0)
    while len(parts) < 3:
        parts.append(0)
    return tuple(parts[:3])

def is_newer(remote_v: str, local_v: str) -> bool:
    return parse_semver(remote_v) > parse_semver(local_v)

def check_for_updates() -> dict[str, Any]:
    """Check update manifest."""
    plat = get_platform_info()
    os_key = "macos_arm64" if plat["is_apple_silicon"] else ("macos_x86_64" if plat["is_intel_mac"] else "windows_x64")

    result = {
        "checked": True,
        "update_available": False,
        "current_version": APP_VERSION,
        "edition": EDITION,
        "latest_version": APP_VERSION,
        "release_notes": "",
        "download_url": "",
        "mandatory": False,
    }

    if not UPDATE_CHECK_URL:
        result["checked"] = False
        return result

    try:
        try:
            import certifi, ssl
            ctx = ssl.create_default_context(cafile=certifi.where())
        except Exception:
            import ssl
            ctx = ssl.create_default_context()
            ctx.check_hostname = False
            ctx.verify_mode = ssl.CERT_NONE

        req = urllib.request.Request(
            f"{UPDATE_CHECK_URL}?edition={EDITION}&version={APP_VERSION}&platform={os_key}",
            headers={"User-Agent": f"LafziUpdater/{APP_VERSION} ({EDITION}; {os_key})"},
        )
        with urllib.request.urlopen(req, context=ctx, timeout=3.0) as resp:
            if resp.status == 200:
                data = json.loads(resp.read().decode("utf-8"))
                latest_v = data.get("latest_version", APP_VERSION)
                if is_newer(latest_v, APP_VERSION):
                    result["update_available"] = True
                    result["latest_version"] = latest_v
                    result["release_notes"] = data.get("release_notes", "A new version of Lafzi is available.")
                    downloads = data.get("download_urls") or {}
                    result["download_url"] = downloads.get(os_key) or data.get("download_url", "https://aurafi.studio/products/lafzi/")
                    result["mandatory"] = bool(data.get("mandatory", False))
    except Exception:
        # Offline or update server not yet running
        result["checked"] = False

    return result
