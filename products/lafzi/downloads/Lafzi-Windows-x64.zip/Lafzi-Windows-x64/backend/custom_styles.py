"""
Custom Caption Styles & Templates Store.
Allows Lafzi Studio users to save, manage, and reuse their custom caption styles.
"""
from __future__ import annotations

import json
import threading
import time
import uuid

from config import ALLOW_CUSTOM_STYLES, CUSTOM_STYLES_FILE

_lock = threading.RLock()

def list_custom_styles() -> list[dict]:
    with _lock:
        if not CUSTOM_STYLES_FILE.exists():
            return []
        try:
            data = json.loads(CUSTOM_STYLES_FILE.read_text(encoding="utf-8"))
            if isinstance(data, list):
                return data
            return []
        except Exception:
            return []

def save_custom_style(name: str, style_dict: dict) -> dict:
    if not ALLOW_CUSTOM_STYLES:
        raise PermissionError("Custom style saving is an exclusive feature of Lafzi Studio.")

    name = name.strip() or "My Custom Style"
    sid = uuid.uuid4().hex[:8]
    item = {
        "id": sid,
        "name": name,
        "createdAt": time.time(),
        "style": style_dict,
    }

    with _lock:
        styles = list_custom_styles()
        styles.insert(0, item)
        tmp = CUSTOM_STYLES_FILE.with_suffix(".tmp")
        tmp.write_text(json.dumps(styles, indent=2, ensure_ascii=False), encoding="utf-8")
        tmp.replace(CUSTOM_STYLES_FILE)

    return item

def delete_custom_style(sid: str) -> bool:
    with _lock:
        styles = list_custom_styles()
        filtered = [s for s in styles if s.get("id") != sid]
        if len(filtered) != len(styles):
            tmp = CUSTOM_STYLES_FILE.with_suffix(".tmp")
            tmp.write_text(json.dumps(filtered, indent=2, ensure_ascii=False), encoding="utf-8")
            tmp.replace(CUSTOM_STYLES_FILE)
            return True
        return False
