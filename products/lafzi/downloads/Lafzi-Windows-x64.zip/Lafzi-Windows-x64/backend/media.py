"""ffmpeg / ffprobe helpers: probing, audio extraction, preview proxies, noise removal."""
from __future__ import annotations

import json
import shutil
import subprocess
from fractions import Fraction
from pathlib import Path

import platform

BACKEND_DIR = Path(__file__).resolve().parent
RNNOISE_MODEL = BACKEND_DIR / "models" / "rnnoise" / "std.rnnn"

def _find_ffmpeg() -> tuple[str, str]:
    ff = shutil.which("ffmpeg")
    fp = shutil.which("ffprobe")
    if ff and fp:
        return ff, fp

    for d in [BACKEND_DIR.parent / "tools", BACKEND_DIR / "tools", BACKEND_DIR.parent]:
        c_ff = d / ("ffmpeg.exe" if platform.system() == "Windows" else "ffmpeg")
        c_fp = d / ("ffprobe.exe" if platform.system() == "Windows" else "ffprobe")
        if c_ff.exists() and (not ff):
            ff = str(c_ff)
        if c_fp.exists() and (not fp):
            fp = str(c_fp)

    if not ff:
        try:
            import imageio_ffmpeg
            ff = imageio_ffmpeg.get_ffmpeg_exe()
        except Exception:
            pass

    if not ff:
        if platform.system() == "Darwin":
            for p in ["/opt/homebrew/bin/ffmpeg", "/usr/local/bin/ffmpeg"]:
                if Path(p).exists():
                    ff = p
                    break
        elif platform.system() == "Windows":
            for p in [r"C:\ffmpeg\bin\ffmpeg.exe", r"C:\Program Files\ffmpeg\bin\ffmpeg.exe"]:
                if Path(p).exists():
                    ff = p
                    break

    if not fp:
        if platform.system() == "Darwin":
            for p in ["/opt/homebrew/bin/ffprobe", "/usr/local/bin/ffprobe"]:
                if Path(p).exists():
                    fp = p
                    break
        elif platform.system() == "Windows":
            for p in [r"C:\ffmpeg\bin\ffprobe.exe", r"C:\Program Files\ffmpeg\bin\ffprobe.exe"]:
                if Path(p).exists():
                    fp = p
                    break

    return ff or "ffmpeg", fp or "ffprobe"

FFMPEG, FFPROBE = _find_ffmpeg()

BROWSER_VIDEO_CODECS = {"h264", "hevc", "vp9", "av1", "vp8"}
BROWSER_CONTAINERS = {".mp4", ".mov", ".m4v", ".webm"}


def run(cmd: list[str], **kw) -> subprocess.CompletedProcess:
    return subprocess.run(cmd, check=True, capture_output=True, text=True, **kw)


def probe(path: Path) -> dict:
    out = run([FFPROBE, "-v", "error", "-print_format", "json", "-show_streams", "-show_format", str(path)]).stdout
    info = json.loads(out)
    v = next((s for s in info["streams"] if s.get("codec_type") == "video"), None)
    a = next((s for s in info["streams"] if s.get("codec_type") == "audio"), None)
    duration = float(info.get("format", {}).get("duration") or (v or a or {}).get("duration") or 0)
    meta = {"duration": duration, "hasAudio": a is not None, "hasVideo": v is not None,
            "width": 0, "height": 0, "fps": 30.0, "videoCodec": None}
    if v:
        w, h = int(v.get("width", 0)), int(v.get("height", 0))
        rot = 0
        for sd in v.get("side_data_list", []) or []:
            if "rotation" in sd:
                rot = int(sd["rotation"])
        rot = int(v.get("tags", {}).get("rotate", rot) or rot)
        if abs(rot) % 180 == 90:
            w, h = h, w
        fps = 30.0
        for key in ("avg_frame_rate", "r_frame_rate"):
            try:
                f = float(Fraction(v.get(key, "0/1")))
                if 1 < f < 241:
                    fps = f
                    break
            except (ZeroDivisionError, ValueError):
                pass
        meta.update(width=w, height=h, fps=round(fps, 3), videoCodec=v.get("codec_name"))
    return meta


def needs_proxy(path: Path, meta: dict) -> bool:
    if not meta["hasVideo"]:
        return False
    return path.suffix.lower() not in BROWSER_CONTAINERS or meta["videoCodec"] not in BROWSER_VIDEO_CODECS


def make_proxy(src: Path, dst: Path) -> None:
    enc = ["-c:v", "h264_videotoolbox"] if platform.system() == "Darwin" else ["-c:v", "libx264", "-preset", "ultrafast"]
    run([FFMPEG, "-y", "-i", str(src)] + enc + ["-b:v", "6M", "-pix_fmt", "yuv420p",
         "-c:a", "aac", "-b:a", "160k", "-movflags", "+faststart", str(dst)])


def extract_audio(src: Path, dst: Path, rate: int = 16000) -> None:
    """Mono PCM wav for Whisper."""
    run([FFMPEG, "-y", "-i", str(src), "-vn", "-ac", "1", "-ar", str(rate), "-c:a", "pcm_s16le", str(dst)])


def denoise_filter(strength: float = 0.85) -> str:
    chain = ["highpass=f=75", "lowpass=f=14000"]
    if RNNOISE_MODEL.exists():
        chain.append(f"arnndn=m='{RNNOISE_MODEL}':mix={max(0.1, min(1.0, strength)):.2f}")
    chain.append(f"afftdn=nr={int(10 + 14 * strength)}:nf=-30:tn=1")
    chain.append("loudnorm=I=-16:TP=-1.5:LRA=11")
    return ",".join(chain)


def denoise_audio(src: Path, dst: Path, strength: float = 0.85) -> None:
    """Studio-ish clean-up: rumble/hiss filters + RNNoise speech denoiser + FFT denoise + loudness."""
    run([FFMPEG, "-y", "-i", str(src), "-vn", "-af", denoise_filter(strength), "-ac", "1", "-ar", "48000",
         "-c:a", "pcm_s16le", str(dst)])


def thumbnail(src: Path, dst: Path, at: float = 0.5) -> None:
    try:
        run([FFMPEG, "-y", "-ss", f"{at:.2f}", "-i", str(src), "-frames:v", "1", "-vf", "scale=480:-2", str(dst)])
    except subprocess.CalledProcessError:
        pass


def detect_speech_regions(audio: Path, duration: float = 0.0,
                          noise_db: float = -38.0, min_silence: float = 0.55) -> list[list[float]]:
    """Return active speech intervals [[start, end], ...] so silent gaps stay uncaptioned."""
    import re
    if duration <= 0:
        try:
            duration = probe(audio)["duration"]
        except Exception:  # noqa: BLE001
            duration = 0.0
    proc = subprocess.run(
        [FFMPEG, "-hide_banner", "-nostats", "-i", str(audio),
         "-af", f"silencedetect=n={noise_db}dB:d={min_silence}", "-f", "null", "-"],
        capture_output=True, text=True, check=False,
    )
    log = proc.stderr or ""
    starts = [float(x) for x in re.findall(r"silence_start:\s*([0-9.]+)", log)]
    ends = [float(x) for x in re.findall(r"silence_end:\s*([0-9.]+)", log)]

    silences: list[tuple[float, float]] = []
    for i, s in enumerate(starts):
        e = ends[i] if i < len(ends) else (duration or s + min_silence)
        if e > s:
            silences.append((s, e))

    if not silences:
        return [[0.0, round(duration, 2)]] if duration > 0 else []

    raw_speech: list[list[float]] = []
    cur = 0.0
    for s, e in silences:
        if s - cur >= 0.18:
            raw_speech.append([max(0.0, cur - 0.08), min(duration or s, s + 0.08)])
        cur = max(cur, e)
    if duration > cur + 0.18:
        raw_speech.append([max(0.0, cur - 0.08), duration])

    # Merge speech intervals that are separated by tiny micro-pauses (< 0.30s)
    merged: list[list[float]] = []
    for seg in raw_speech:
        if seg[1] - seg[0] < 0.20:
            continue
        if merged and seg[0] - merged[-1][1] < 0.30:
            merged[-1][1] = round(seg[1], 2)
        else:
            merged.append([round(seg[0], 2), round(seg[1], 2)])
    return merged


def compute_waveform(audio_path: Path, num_bars: int = 360) -> list[float]:
    """Compute normalized [0.05 .. 1.0] amplitude peaks from 16kHz mono PCM wav for timeline display."""
    import array
    import wave

    if not audio_path.exists():
        return [0.12] * num_bars
    try:
        with wave.open(str(audio_path), "rb") as wf:
            n_frames = wf.getnframes()
            if n_frames <= 0:
                return [0.12] * num_bars
            raw = wf.readframes(n_frames)
        samples = array.array("h")
        samples.frombytes(raw)
        total = len(samples)
        if total == 0:
            return [0.12] * num_bars

        step = max(1, total // num_bars)
        peaks: list[float] = []
        for i in range(num_bars):
            start = i * step
            end = min(total, start + step)
            chunk = samples[start:end]
            if not chunk:
                peaks.append(0.0)
                continue
            # Sub-sample every 4th frame for speed (~4,000 samples/sec is plenty for envelope)
            sub = chunk[::4] or chunk
            pk = max(abs(x) for x in sub)
            peaks.append(float(pk))

        max_pk = max(peaks) if peaks else 1.0
        if max_pk <= 0:
            max_pk = 1.0
        return [round(max(0.05, min(1.0, (p / max_pk) ** 0.72)), 3) for p in peaks]
    except Exception:  # noqa: BLE001
        return [0.15] * num_bars


