"""
Caption renderer used for burned-in export.

This is a 1:1 port of `frontend/src/lib/captionRenderer.js` (the live preview).
If you change layout maths in one, change it in the other so the exported
video matches what the user saw in the editor.

All sizes in the style are expressed in pixels for a 1080px short side and
scaled to the real video resolution.
"""
from __future__ import annotations

import re
from functools import lru_cache

from PIL import Image, ImageDraw, ImageFilter, ImageFont

from fonts import font_path, font_path_for_text

DEFAULT_STYLE = {
    "template": "hormozi",
    "fontFamily": "Poppins Black",
    "fontSize": 78,
    "uppercase": True,
    "punctuation": False,
    "textColor": "#FFFFFF",
    "highlightMode": "color",       # color | box | fill | none
    "highlightColor": "#FFE81F",
    "highlightTextColor": "#000000",
    "strokeColor": "#000000",
    "strokeWidth": 7,
    "shadow": True,
    "shadowColor": "#000000",
    "shadowOpacity": 0.55,
    "shadowBlur": 10,
    "shadowOffsetY": 5,
    "bgBox": False,
    "bgColor": "#000000",
    "bgOpacity": 0.6,
    "bgPadding": 22,
    "bgRadius": 18,
    "positionY": 70,
    "maxWidth": 82,
    "lineHeight": 1.18,
    "wordSpacing": 0.28,
    "wordsPerCaption": 3,
    "animation": "pop",             # pop | bounce | fade | none
    "wordAnim": "pop",              # pop | none
    "activeScale": 1.12,
}

ENTRANCE_DUR = 0.11
WORD_DUR = 0.08
CENTER_K = 0.35   # visual centre of a line = baseline - CENTER_K * fontSize
BOX_HALF_H = 0.62
BOX_PAD_X = 0.18

_PUNCT_RE = re.compile(r"[.,!?;:\"“”…،۔]")
_RTL_RE = re.compile(r"[\u0600-\u06FF]")


def display_text(text: str, style: dict) -> str:
    if not style.get("punctuation"):
        text = _PUNCT_RE.sub("", text).strip("'")
    if _RTL_RE.search(text):
        return text
    return text.upper() if style.get("uppercase") else text


def ease_out_back(x: float) -> float:
    c1 = 1.70158
    c3 = c1 + 1
    return 1 + c3 * (x - 1) ** 3 + c1 * (x - 1) ** 2


def clamp01(x: float) -> float:
    return 0.0 if x < 0 else 1.0 if x > 1 else x


def hex_rgb(h: str) -> tuple[int, int, int]:
    h = h.lstrip("#")
    if len(h) == 3:
        h = "".join(c * 2 for c in h)
    return int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)


@lru_cache(maxsize=256)
def _font(path: str, size: int) -> ImageFont.FreeTypeFont:
    return ImageFont.truetype(path, max(1, size))


class CaptionRenderer:
    def __init__(self, style: dict, width: int, height: int):
        self.s = {**DEFAULT_STYLE, **(style or {})}
        self.W, self.H = width, height
        self.k = min(width, height) / 1080.0
        self.size = self.s["fontSize"] * self.k
        self.path = font_path(self.s["fontFamily"])
        self._layout_cache: dict = {}

    # ------------------------------------------------------------------ layout
    def font(self, size: float, text: str = ""):
        p = font_path_for_text(self.s["fontFamily"], text) if text else self.path
        return _font(p, int(round(size)))

    def measure(self, text: str, size: float) -> float:
        return self.font(size, text).getlength(text)

    def layout(self, cue: dict):
        key = (id(cue), tuple(w["text"] for w in cue["words"]))
        hit = self._layout_cache.get(key)
        if hit:
            return hit
        s, size = self.s, self.size
        space = s["wordSpacing"] * size
        max_w = s["maxWidth"] / 100.0 * self.W
        items = []
        is_rtl = False
        for i, w in enumerate(cue["words"]):
            t = display_text(w["text"], s)
            if t:
                if _RTL_RE.search(t):
                    is_rtl = True
                items.append((i, t, self.measure(t, size)))
        lines, cur, cur_w = [], [], 0.0
        for it in items:
            add = it[2] if not cur else space + it[2]
            if cur and cur_w + add > max_w:
                lines.append((cur, cur_w))
                cur, cur_w = [it], it[2]
            else:
                cur.append(it)
                cur_w += add
        if cur:
            lines.append((cur, cur_w))
        line_h = s["lineHeight"] * size
        block_h = len(lines) * line_h
        cy = s["positionY"] / 100.0 * self.H
        top = cy - block_h / 2
        placed = []
        max_line_w = 0.0
        for li, (ws, lw) in enumerate(lines):
            max_line_w = max(max_line_w, lw)
            x = (self.W - lw) / 2
            baseline = top + li * line_h + line_h / 2 + CENTER_K * size
            ordered_ws = list(reversed(ws)) if is_rtl else ws
            for (idx, t, w) in ordered_ws:
                placed.append({"idx": idx, "text": t, "w": w, "cx": x + w / 2, "cy": baseline - CENTER_K * size})
                x += w + space
        out = {"words": placed, "cy": cy, "block_h": block_h, "max_w": max_line_w}
        self._layout_cache[key] = out
        return out

    def extent(self, cues: list[dict]) -> tuple[int, int]:
        """Vertical band (top, height) that can contain every caption incl. animation."""
        s = self.s
        if not cues:
            cy = int(s["positionY"] / 100.0 * self.H)
            return max(0, cy - 2), 4
        max_h = max(self.layout(c)["block_h"] for c in cues)
        grow = max(s["activeScale"], 1.0) * 1.12
        pad = (s["strokeWidth"] + s["shadowBlur"] * 1.5 + abs(s["shadowOffsetY"]) + s["bgPadding"]) * self.k + self.size * 0.9
        cy = s["positionY"] / 100.0 * self.H
        top = int(max(0, cy - max_h / 2 * grow - pad))
        bot = int(min(self.H, cy + max_h / 2 * grow + pad))
        if (bot - top) % 2:
            bot = bot - 1 if bot == self.H else bot + 1
        return top, max(2, bot - top)

    # ------------------------------------------------------------------- state
    def state(self, cue: dict, t: float):
        s = self.s
        p = clamp01((t - cue["start"]) / ENTRANCE_DUR)
        active = 0
        for i, w in enumerate(cue["words"]):
            if w["start"] <= t:
                active = i
        q = 1.0
        if active >= 0 and cue["words"]:
            q = clamp01((t - cue["words"][active]["start"]) / WORD_DUR)
        if s["animation"] == "none":
            p = 1.0
        if s["wordAnim"] == "none":
            q = 1.0
        return round(p, 3), active, round(q, 3)

    def state_key(self, cue_idx: int, cue: dict, t: float):
        return (cue_idx,) + self.state(cue, t)

    # ------------------------------------------------------------------ render
    def render(self, cue: dict, t: float, band_top: int = 0, band_h: int | None = None) -> Image.Image:
        s, size, k = self.s, self.size, self.k
        band_h = band_h or self.H
        img = Image.new("RGBA", (self.W, band_h), (0, 0, 0, 0))
        lay = self.layout(cue)
        if not lay["words"]:
            return img
        p, active, q = self.state(cue, t)

        cs, dy, alpha = 1.0, 0.0, 1.0
        anim = s["animation"]
        if anim == "pop":
            cs = 0.85 + 0.15 * ease_out_back(p)
            alpha = clamp01(0.78 + p * 2.2)
        elif anim == "bounce":
            dy = (1 - ease_out_back(p)) * size * 0.45
            alpha = clamp01(0.78 + p * 2.2)
        elif anim == "fade":
            alpha = clamp01(0.35 + p * 0.65)

        cx0, cy0 = self.W / 2, lay["cy"]

        def tx(x, y):
            return cx0 + (x - cx0) * cs, cy0 + (y - cy0) * cs + dy - band_top

        draw = ImageDraw.Draw(img)

        # background box behind the whole caption
        if s["bgBox"]:
            pad = s["bgPadding"] * k
            hw = lay["max_w"] / 2 + pad
            hh = lay["block_h"] / 2 + pad * 0.6
            x1, y1 = tx(cx0 - hw, cy0 - hh)
            x2, y2 = tx(cx0 + hw, cy0 + hh)
            r, g, b = hex_rgb(s["bgColor"])
            box = Image.new("RGBA", img.size, (0, 0, 0, 0))
            ImageDraw.Draw(box).rounded_rectangle(
                [x1, y1, x2, y2], radius=s["bgRadius"] * k * cs, fill=(r, g, b, int(255 * s["bgOpacity"])))
            img = Image.alpha_composite(img, box)
            draw = ImageDraw.Draw(img)

        # resolve per-word drawing params
        words = []
        for pw in lay["words"]:
            i = pw["idx"]
            is_active = i == active
            ws = 1.0
            if is_active and s["highlightMode"] != "none":
                ws = 1 + (s["activeScale"] - 1) * (ease_out_back(q) if s["wordAnim"] == "pop" else 1)
            fsz = size * cs * ws
            x, y = tx(pw["cx"], pw["cy"])
            color = s["textColor"]
            mode = s["highlightMode"]
            if mode in ("color", "glow", "underline") and is_active:
                color = s["highlightColor"]
            elif mode == "fill" and i <= active:
                color = s["highlightColor"]
            elif mode == "box" and is_active:
                color = s["highlightTextColor"]
            words.append({"text": pw["text"], "x": x, "y": y, "fsz": fsz, "w": pw["w"] * cs * ws,
                          "color": color, "active": is_active})

        stroke = s["strokeWidth"] * k

        # shadow / glow layer
        if s["shadow"] and s["shadowOpacity"] > 0:
            mask = Image.new("L", img.size, 0)
            md = ImageDraw.Draw(mask)
            off = s["shadowOffsetY"] * k
            for w in words:
                sw = int(round(stroke * w["fsz"] / size)) if stroke > 0 else 0
                md.text((w["x"], w["y"] + CENTER_K * w["fsz"] + off), w["text"], font=self.font(w["fsz"], w["text"]),
                        anchor="ms", fill=255, stroke_width=sw, stroke_fill=255)
            blur = s["shadowBlur"] * k / 2
            if blur > 0.3:
                mask = mask.filter(ImageFilter.GaussianBlur(blur))
            mask = mask.point(lambda v: int(v * s["shadowOpacity"]))
            shade = Image.new("RGBA", img.size, hex_rgb(s["shadowColor"]) + (0,))
            shade.putalpha(mask)
            img = Image.alpha_composite(img, shade)
            draw = ImageDraw.Draw(img)

        # neon aura for active word when highlightMode == "glow"
        if s["highlightMode"] == "glow":
            for w in words:
                if w["active"]:
                    gmask = Image.new("L", img.size, 0)
                    gd = ImageDraw.Draw(gmask)
                    gd.text((w["x"], w["y"] + CENTER_K * w["fsz"]), w["text"], font=self.font(w["fsz"], w["text"]),
                            anchor="ms", fill=255, stroke_width=int(max(2, w["fsz"] * 0.08)), stroke_fill=255)
                    gmask = gmask.filter(ImageFilter.GaussianBlur(max(2.0, w["fsz"] * 0.22)))
                    gmask = gmask.point(lambda v: min(255, int(v * 0.85)))
                    glow_img = Image.new("RGBA", img.size, hex_rgb(s["highlightColor"]) + (0,))
                    glow_img.putalpha(gmask)
                    img = Image.alpha_composite(img, glow_img)
                    draw = ImageDraw.Draw(img)

        # highlight box or underline behind the active word
        if s["highlightMode"] == "box":
            for w in words:
                if w["active"]:
                    hh = BOX_HALF_H * w["fsz"]
                    px = BOX_PAD_X * w["fsz"]
                    draw.rounded_rectangle(
                        [w["x"] - w["w"] / 2 - px, w["y"] - hh, w["x"] + w["w"] / 2 + px, w["y"] + hh * 0.85],
                        radius=0.18 * w["fsz"], fill=hex_rgb(s["highlightColor"]) + (255,))
        elif s["highlightMode"] == "underline":
            for w in words:
                if w["active"]:
                    uy = w["y"] + CENTER_K * w["fsz"] + 0.10 * w["fsz"]
                    uh = max(4.0, 0.11 * w["fsz"])
                    px = 0.06 * w["fsz"]
                    draw.rounded_rectangle(
                        [w["x"] - w["w"] / 2 - px, uy, w["x"] + w["w"] / 2 + px, uy + uh],
                        radius=uh / 2, fill=hex_rgb(s["highlightColor"]) + (255,))

        stroke_rgb = hex_rgb(s["strokeColor"])
        for w in words:
            sw = int(round(stroke * w["fsz"] / size)) if stroke > 0 else 0
            if w["active"] and s["highlightMode"] == "box":
                sw = 0
            draw.text((w["x"], w["y"] + CENTER_K * w["fsz"]), w["text"], font=self.font(w["fsz"], w["text"]), anchor="ms",
                      fill=hex_rgb(w["color"]) + (255,), stroke_width=sw, stroke_fill=stroke_rgb + (255,))

        if alpha < 0.999:
            a = img.getchannel("A").point(lambda v: int(v * alpha))
            img.putalpha(a)
        return img
