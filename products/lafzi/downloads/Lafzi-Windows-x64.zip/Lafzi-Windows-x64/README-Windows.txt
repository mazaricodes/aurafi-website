==============================================================================
  🎬 LAFZI STUDIO — Windows 10 & 11 (64-bit)
  100% Offline AI Video Captioning Studio for South Asian Creators
==============================================================================

QUICK START INSTRUCTIONS:
-------------------------
1. Make sure Python 3.10 or newer is installed on your Windows machine:
   Download: https://www.python.org/downloads/
   *IMPORTANT*: During Python installation, check the box:
   [x] "Add python.exe to PATH"

2. Double-click "start_studio_windows.bat" to launch!
   - On first run, it will automatically install required lightweight packages.
   - It will open Lafzi Studio in a clean native desktop window.

3. System Requirements:
   - Windows 10 or Windows 11 (64-bit)
   - 8 GB RAM minimum (16 GB recommended)
   - GPU acceleration: Supported automatically via DirectML / CUDA

4. Support & Updates:
   - Official Website: https://aurafi.studio/products/lafzi/
   - Questions / Feedback: hello@aurafi.studio
==============================================================================
