"""
Lafzi Windows Native Desktop Launcher.
Runs the Lafzi / Lafzi Studio engine and opens in a standalone native desktop window
using Microsoft Edge App Mode (available natively on 100% of Windows 10/11 machines).
"""
import os
import sys
import time
import shutil
import platform
import subprocess
import threading
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
BACKEND = ROOT / "backend"
FRONTEND_DIST = ROOT / "frontend" / "dist"

EDITION = os.getenv("LAFZI_EDITION", "base").strip().lower()
IS_STUDIO = (EDITION == "studio")
PORT = int(os.getenv("PORT", "8766" if IS_STUDIO else "8765"))
APP_TITLE = "Lafzi Studio — Desi Captions Studio" if IS_STUDIO else "Lafzi — Desi Captions Studio"
URL = f"http://127.0.0.1:{PORT}"

def start_backend():
    sys.path.insert(0, str(BACKEND))
    try:
        import uvicorn
    except ImportError:
        print("[!] Uvicorn not found in current environment.")
        print("[*] Automatically installing required dependencies, please wait...")
        req_file = BACKEND / "requirements.txt"
        if req_file.exists():
            subprocess.check_call([sys.executable, "-m", "pip", "install", "-r", str(req_file)])
        else:
            subprocess.check_call([sys.executable, "-m", "pip", "install", "fastapi", "uvicorn[standard]", "python-multipart", "pydantic", "pillow", "numpy", "scipy", "tqdm", "requests", "certifi", "imageio-ffmpeg"])
        import uvicorn
    uvicorn.run("app:app", host="127.0.0.1", port=PORT, log_level="info", app_dir=str(BACKEND))

def wait_for_server(timeout=25):
    health = f"{URL}/api/health"
    start = time.time()
    while time.time() - start < timeout:
        try:
            with urllib.request.urlopen(health, timeout=1.0) as resp:
                if resp.status == 200:
                    return True
        except Exception:
            time.sleep(0.3)
    return False

def open_window():
    # 1. Look for Microsoft Edge on Windows to launch in native frameless app mode
    edge_paths = [
        os.path.expandvars(r"%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"),
        os.path.expandvars(r"%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"),
        os.path.expandvars(r"%LocalAppData%\Microsoft\Edge\Application\msedge.exe"),
    ]
    edge_exe = next((p for p in edge_paths if os.path.exists(p)), None)

    if edge_exe:
        cmd = [
            edge_exe,
            f"--app={URL}",
            "--window-size=1440,900",
            f"--app-id=app.lafzi.{EDITION}",
            "--new-window",
        ]
        proc = subprocess.Popen(cmd)
        proc.wait()
        # When user closes window, terminate the app
        os._exit(0)
    else:
        # Fallback to default browser
        import webbrowser
        webbrowser.open(URL)

def main():
    os.environ["LAFZI_EDITION"] = EDITION
    print("=" * 60)
    print(f"  🎬 {APP_TITLE} (Windows x64)")
    print(f"  Engine starting at: {URL}")
    print("=" * 60)

    # Start backend in background thread
    t = threading.Thread(target=start_backend, daemon=True)
    t.start()

    if wait_for_server():
        open_window()
    else:
        print(f"Server did not respond in time. Please visit {URL} manually.")

    # Keep alive if browser fallback was used
    while True:
        time.sleep(1)

if __name__ == "__main__":
    main()
