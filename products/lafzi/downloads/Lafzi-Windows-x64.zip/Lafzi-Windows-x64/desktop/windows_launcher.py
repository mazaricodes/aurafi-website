"""
Lafzi Windows Native Desktop Launcher.
Runs the Lafzi / Lafzi Studio engine and opens in a standalone native desktop window
using Microsoft Edge App Mode (available natively on 100% of Windows 10/11 machines).
"""
import os
import sys
import time
import shutil
import platform
import subprocess
import threading
import urllib.request
import webbrowser
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
BACKEND = ROOT / "backend"
FRONTEND_DIST = ROOT / "frontend" / "dist"

EDITION = os.getenv("LAFZI_EDITION", "base").strip().lower()
IS_STUDIO = (EDITION == "studio")
PORT = int(os.getenv("PORT", "8766" if IS_STUDIO else "8765"))
APP_TITLE = "Lafzi Studio — Desi Captions Studio" if IS_STUDIO else "Lafzi — Desi Captions Studio"
URL = f"http://127.0.0.1:{PORT}"

def start_backend():
    cmd = [
        sys.executable,
        "-m", "uvicorn",
        "app:app",
        "--host", "127.0.0.1",
        "--port", str(PORT),
        "--app-dir", str(BACKEND)
    ]
    env = os.environ.copy()
    env["LAFZI_EDITION"] = EDITION
    env["PYTHONPATH"] = str(BACKEND)

    kwargs = {}
    if sys.platform == "win32":
        # CREATE_NO_WINDOW = 0x08000000
        kwargs["creationflags"] = 0x08000000

    log_path = ROOT / "backend.log"
    log_file = open(log_path, "w", encoding="utf-8")
    proc = subprocess.Popen(cmd, cwd=str(BACKEND), env=env, stdout=log_file, stderr=subprocess.STDOUT, **kwargs)
    return proc

def wait_for_server(timeout=35):
    health = f"{URL}/api/health"
    start = time.time()
    while time.time() - start < timeout:
        try:
            with urllib.request.urlopen(health, timeout=1.0) as resp:
                if resp.status == 200:
                    return True
        except Exception:
            time.sleep(0.3)
    return False

def open_window():
    edge_paths = [
        os.path.expandvars(r"%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"),
        os.path.expandvars(r"%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"),
        os.path.expandvars(r"%LocalAppData%\Microsoft\Edge\Application\msedge.exe"),
    ]
    edge_exe = next((p for p in edge_paths if os.path.exists(p)), None)

    if edge_exe:
        cmd = [
            edge_exe,
            f"--app={URL}",
            "--window-size=1440,900",
            f"--app-id=app.lafzi.{EDITION}",
            "--new-window",
        ]
        proc = subprocess.Popen(cmd)
        proc.wait()
        os._exit(0)
    else:
        webbrowser.open(URL)

def main():
    os.environ["LAFZI_EDITION"] = EDITION
    backend_proc = start_backend()

    if wait_for_server(timeout=35):
        open_window()
    else:
        webbrowser.open(URL)

    # Monitor backend process
    while True:
        if backend_proc.poll() is not None:
            break
        time.sleep(1)

if __name__ == "__main__":
    main()
