@echo off
REM ==============================================================================
REM  🎬 LAFZI / LAFZI STUDIO — Windows 10/11 Desktop Launcher
REM ==============================================================================
TITLE Lafzi Desktop Launcher
cd /d "%~dp0"

echo ==========================================================
echo   LAFZI — Offline Native & Roman Captions Studio
echo ==========================================================
echo.
echo Choose an edition to launch:
echo   [1] Lafzi (2 Min Cap)
echo   [2] Lafzi Studio (Unlimited Duration + Studio Features)
echo.

set /p CHOICE="Enter choice [1 or 2, default is 1]: "

if "%CHOICE%"=="2" (
    echo.
    echo Starting Lafzi Studio...
    set "LAFZI_EDITION=studio"
    set "PORT=8766"
) else (
    echo.
    echo Starting Lafzi...
    set "LAFZI_EDITION=base"
    set "PORT=8765"
)

REM Check Python installation
where python >nul 2>nul
if %errorlevel% neq 0 (
    echo [ERROR] Python 3.10+ was not found in PATH.
    echo Please install Python from https://www.python.org/downloads/
    pause
    exit /b 1
)

REM Check Virtual Environment
if exist ".venv\Scripts\python.exe" (
    set "PY_BIN=.venv\Scripts\python.exe"
) else if exist "venv\Scripts\python.exe" (
    set "PY_BIN=venv\Scripts\python.exe"
) else (
    set "PY_BIN=python"
)

REM Run Windows Launcher
"%PY_BIN%" desktop\windows_launcher.py

pause
