@echo off
REM ==============================================================================
REM  LAFZI -- Windows 10/11 Desktop Launcher
REM ==============================================================================
TITLE Lafzi
cd /d "%~dp0"

set "LAFZI_EDITION=base"
set "PORT=8765"

REM 1. Check Python installation
where python >nul 2>nul
if %errorlevel% neq 0 (
    echo [ERROR] Python 3.10+ was not found in PATH.
    echo Please install Python from https://www.python.org/downloads/
    echo (Make sure to check "Add Python to PATH" during installation)
    pause
    exit /b 1
)

REM 2. Setup Virtual Environment
if not exist ".venv\Scripts\python.exe" (
    echo Setting up Python environment (first-time setup, please wait)...
    python -m venv .venv
)

if exist ".venv\Scripts\python.exe" (
    set "PY_BIN=.venv\Scripts\python.exe"
) else (
    set "PY_BIN=python"
)

REM 3. Check and install dependencies
"%PY_BIN%" -c "import fastapi, uvicorn" >nul 2>nul
if %errorlevel% neq 0 (
    echo Installing required packages (first-time setup only, please wait)...
    "%PY_BIN%" -m pip install --upgrade pip
    if exist "backend\requirements.txt" (
        "%PY_BIN%" -m pip install -r backend\requirements.txt
    ) else (
        "%PY_BIN%" -m pip install fastapi "uvicorn[standard]" python-multipart pydantic pillow numpy scipy tqdm requests certifi imageio-ffmpeg
    )
)

REM 4. Run Windows Native Launcher
"%PY_BIN%" desktop\windows_launcher.py
