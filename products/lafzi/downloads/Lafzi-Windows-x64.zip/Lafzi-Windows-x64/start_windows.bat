@echo off
REM ==============================================================================
REM  LAFZI / LAFZI STUDIO -- Windows 10/11 Desktop Launcher
REM ==============================================================================
TITLE Lafzi Desktop Launcher
cd /d "%~dp0"

echo ==========================================================
echo   LAFZI -- Offline Native and Roman Captions Studio
echo ==========================================================
echo.
echo Choose an edition to launch:
echo   [1] Lafzi (2 Min Cap)
echo   [2] Lafzi Studio (Unlimited Duration + Studio Features)
echo.

set /p CHOICE="Enter choice [1 or 2, default is 1]: "

if "%CHOICE%"=="2" (
    echo.
    echo Starting Lafzi Studio...
    set "LAFZI_EDITION=studio"
    set "PORT=8766"
) else (
    echo.
    echo Starting Lafzi...
    set "LAFZI_EDITION=base"
    set "PORT=8765"
)

REM 1. Check Python installation
where python >nul 2>nul
if %errorlevel% neq 0 (
    echo [ERROR] Python 3.10+ was not found in PATH.
    echo Please install Python from https://www.python.org/downloads/
    echo (Make sure to check "Add Python to PATH" during installation)
    pause
    exit /b 1
)

REM 2. Setup Virtual Environment (creates isolated .venv in folder)
if not exist ".venv\Scripts\python.exe" (
    echo Setting up Python virtual environment (first-time setup)...
    python -m venv .venv
)

if exist ".venv\Scripts\python.exe" (
    set "PY_BIN=.venv\Scripts\python.exe"
) else (
    set "PY_BIN=python"
)

REM 3. Check and install dependencies
echo Checking dependencies...
"%PY_BIN%" -c "import fastapi, uvicorn" >nul 2>nul
if %errorlevel% neq 0 (
    echo Installing required packages (first-time setup only, please wait)...
    "%PY_BIN%" -m pip install --upgrade pip
    if exist "backend\requirements.txt" (
        "%PY_BIN%" -m pip install -r backend\requirements.txt
    ) else (
        "%PY_BIN%" -m pip install fastapi "uvicorn[standard]" python-multipart pydantic pillow numpy scipy tqdm requests certifi imageio-ffmpeg openai-whisper
    )
)

REM 4. Run Windows Native Launcher
"%PY_BIN%" desktop\windows_launcher.py

pause
