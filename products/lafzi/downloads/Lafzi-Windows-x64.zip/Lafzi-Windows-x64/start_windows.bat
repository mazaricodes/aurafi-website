@echo off
TITLE Lafzi Setup
cd /d "%~dp0"

set "LAFZI_EDITION=base"
set "PORT=8765"

echo ==========================================================
echo   LAFZI -- Initializing Desktop Engine (First Run)
echo ==========================================================
echo.
echo [*] Checking Python installation...
where python >nul 2>nul
if %errorlevel% neq 0 (
    echo [ERROR] Python 3.10+ was not found in PATH.
    echo Please install Python from https://www.python.org/downloads/
    echo (Make sure to check "Add Python to PATH" during installation)
    pause
    exit /b 1
)

if not exist ".venv\Scripts\python.exe" (
    echo [*] Setting up Python virtual environment...
    python -m venv .venv
)

if exist ".venv\Scripts\python.exe" (
    set "PY_BIN=.venv\Scripts\python.exe"
) else (
    set "PY_BIN=python"
)

"%PY_BIN%" -c "import fastapi, uvicorn" >nul 2>nul
if %errorlevel% neq 0 (
    echo [*] Installing required lightweight packages (takes ~4 seconds)...
    "%PY_BIN%" -m pip install -r backend\requirements.txt
)

echo.
echo [OK] Setup complete! Starting Lafzi...
timeout /t 1 /nobreak >nul
